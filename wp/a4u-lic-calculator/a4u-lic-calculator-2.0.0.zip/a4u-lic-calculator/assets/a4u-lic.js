/* A4U LIC Calculator v2.0 — frontend (educational illustration only) */
(function () {
	'use strict';

	var C = window.A4U_LIC;
	var root = document.getElementById('a4u-lic-app');
	if (!C || !root) { return; }

	// mode => [label, वर्षात किती हप्ते]
	var MODES = { yearly: ['Yearly', 1], half: ['Half-yearly', 2], quarter: ['Quarterly', 4], month: ['Monthly', 12] };
	// verified rates नसतील तेव्हा फक्त अंदाजासाठी demo factor
	var DEMO_FACTOR = { endowment: 0.98, anand: 1.02, labh: 0.84, lakshya: 0.9, umang: 1.25, utsav: 1.6 };
	var SINGLE = { single: 1, utsav_sp: 1 };       // एकदाच premium भरायचे plans
	var BY_PPT = { umang: 1, utsav: 1, utsav_sp: 1 }; // rate key = PPT / GA period
	var RIDERS = { adb: 'Accident Benefit rider', addb: 'Accidental Death & Disability rider', term: 'Term Assurance rider', pwb: 'Premium Waiver Benefit rider' };
	var rateCache = {};
	var last = null; // शेवटचा निकाल — WhatsApp/lead/compare साठी
	var lastCmp = null; // presentation मध्ये तुलना दाखवण्यासाठी
	var nf = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });

	/* ---------- छोटे helpers ---------- */
	function inr(n) { var v = Math.round(n); return (v < 0 ? '\u2212' : '') + '\u20B9' + nf.format(Math.abs(v)); }
	function esc(s) {
		return String(s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}
	function planById(id) {
		for (var i = 0; i < C.plans.length; i++) { if (C.plans[i].id === id) { return C.plans[i]; } }
		return null;
	}
	function f(form, name) { return form.elements.namedItem(name); }
	function has(p, rider) { return (p.riders || []).indexOf(rider) > -1; }
	// plain permalinks (?rest_route=) असल्यास पण URL बरोबर बनतो
	function api(path, qs) {
		var sep = C.rest.indexOf('?') > -1 ? '&' : '?';
		return C.rest + path + (qs ? sep + qs : '');
	}
	function post(path, body) {
		return fetch(api(path), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), keepalive: true });
	}
	function track(ev) { try { post('track', { event: ev }).catch(function () {}); } catch (e) { /* stats न गेल्यास काही बिघडत नाही */ } }

	if (!C.plans || !C.plans.length) {
		root.innerHTML = '<p class="a4u-note">The calculator is being updated. Please check back soon.</p>';
		return;
	}

	/* ---------- SA multiples (S2) ---------- */
	function slabFor(p, sa) {
		var s = null;
		(p.sa_slabs || []).forEach(function (x) { if (sa >= x[0]) { s = x; } });
		return s;
	}
	function floorToSlab(p, sa) {
		var s = slabFor(p, sa);
		return s ? Math.floor(sa / s[1]) * s[1] : sa;
	}

	/* ---------- Form ---------- */
	function field(label, input, cls) { return '<label class="a4u-field' + (cls ? ' ' + cls : '') + '"><span>' + label + '</span>' + input + '</label>'; }

	var planOpts = C.plans.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.name) + '</option>'; }).join('');
	var modeOpts = Object.keys(MODES).map(function (k) { return '<option value="' + k + '">' + MODES[k][0] + '</option>'; }).join('');

	root.innerHTML =
		'<form class="a4u-form" novalidate>' +
		'<h2 class="a4u-title">' + esc(C.title || 'LIC Premium & Benefit Calculator') + '</h2>' +
		'<p class="a4u-sub">Educational illustration — not an official LIC quotation.</p>' +
		field('Plan', '<select name="plan">' + planOpts + '</select>') +
		'<div class="a4u-row">' +
		field('Date of birth', '<input type="date" name="dob">') +
		field('or Age (years)', '<input type="number" name="age" min="0" max="99" inputmode="numeric" placeholder="e.g. 30">') +
		'</div>' +
		'<div class="a4u-seg" role="radiogroup" aria-label="Calculate by">' +
		'<label><input type="radio" name="by" value="sa" checked> By Sum Assured</label>' +
		'<label><input type="radio" name="by" value="budget"> By Premium budget</label>' +
		'</div>' +
		field('Sum Assured (₹)', '<input type="number" name="sa" min="200000" step="5000" value="500000" inputmode="numeric"><small data-sa-hint></small>', 'a4u-by-sa') +
		field('<span data-budget-label>Premium you can pay per installment (₹)</span>', '<input type="number" name="budget" min="1000" step="500" value="10000" inputmode="numeric">', 'a4u-by-budget') +
		'<div class="a4u-row">' +
		field('<span data-term-label>Policy term</span>', '<select name="term"></select>') +
		field('Payment mode', '<select name="mode">' + modeOpts + '</select>', 'a4u-mode') +
		'</div>' +
		field('Income option', '<select name="income"><option value="regular">Regular Income (paid every year)</option><option value="flexi">Flexi Income (accumulate @ 5.5% p.a.)</option></select>', 'a4u-income') +
		'<details class="a4u-adv"><summary>Riders &amp; GST</summary>' +
		'<div data-riders></div>' +
		field('GST % on premium', '<input type="number" name="gst" min="0" max="28" step="0.01" value="' + Number(C.gst) + '">') +
		'</details>' +
		'<div class="a4u-error" role="alert" hidden></div>' +
		'<button type="submit" class="a4u-btn a4u-calc">Calculate</button>' +
		'</form>' +
		'<section class="a4u-result" hidden aria-live="polite"></section>';

	var form = root.querySelector('.a4u-form');
	var result = root.querySelector('.a4u-result');
	var errBox = root.querySelector('.a4u-error');
	var calcBtn = root.querySelector('.a4u-calc');

	function termText(p, t) {
		if (p.type === 'utsav_sp') { return t + ' years (income from year ' + (t + 1) + ')'; }
		if (p.type === 'labh') { return t + ' years (pay ' + p.ppt_map[t] + ' years)'; }
		if (p.type === 'lakshya') { return t + ' years (pay ' + (t - 3) + ' years)'; }
		return t + ' years';
	}
	function termLabel(p) { return p.type === 'utsav_sp' ? 'Guaranteed Addition period' : (BY_PPT[p.type] ? 'Premium paying term' : 'Policy term'); }

	function riderHtml(p) {
		var h = '';
		if (has(p, 'adb')) { h += '<div class="a4u-rider"><label class="a4u-check"><input type="checkbox" name="r_adb" value="1"> ' + RIDERS.adb + '</label>' + field('Rider Sum Assured (up to 3 × SA; blank = SA)', '<input type="number" name="r_adb_sa" min="0" step="5000" inputmode="numeric">', 'a4u-sub-field') + '</div>'; }
		if (has(p, 'addb')) { h += '<div class="a4u-rider"><label class="a4u-check"><input type="checkbox" name="r_addb" value="1"> ' + RIDERS.addb + ' (age 18–60)</label></div>'; }
		if (has(p, 'term')) { h += '<div class="a4u-rider"><label class="a4u-check"><input type="checkbox" name="r_term" value="1"> ' + RIDERS.term + ' (age 18+)</label>' + field('Term rider Sum Assured (up to SA; blank = SA)', '<input type="number" name="r_term_sa" min="0" step="5000" inputmode="numeric">', 'a4u-sub-field') + '</div>'; }
		if (has(p, 'pwb')) { h += '<div class="a4u-rider"><label class="a4u-check"><input type="checkbox" name="r_pwb" value="1"> ' + RIDERS.pwb + ' (child policies)</label>' + field('Proposer / parent age', '<input type="number" name="r_pwb_age" min="18" max="50" inputmode="numeric">', 'a4u-sub-field') + '</div>'; }
		return h || '<p class="a4u-note">No riders for this plan.</p>';
	}

	// plan बदलला की term, mode, riders, SA hint सगळं बदल
	function fillPlanUI() {
		var p = planById(f(form, 'plan').value);
		var sel = f(form, 'term'), prev = parseInt(sel.value, 10);
		sel.innerHTML = p.terms.map(function (t) { return '<option value="' + t + '">' + termText(p, t) + '</option>'; }).join('');
		if (p.terms.indexOf(prev) > -1) { sel.value = prev; }
		root.querySelector('[data-term-label]').textContent = termLabel(p);
		var single = !!SINGLE[p.type];
		root.querySelector('.a4u-mode').hidden = single;
		root.querySelector('.a4u-income').hidden = !(p.type === 'utsav' || p.type === 'utsav_sp');
		root.querySelector('[data-budget-label]').textContent = single ? 'One-time premium you can invest (₹)' : 'Premium you can pay per installment (₹)';
		var sa = f(form, 'sa');
		sa.min = p.min_sa;
		var s0 = (p.sa_slabs || [])[0];
		sa.step = s0 ? s0[1] : 1000;
		if (parseInt(sa.value, 10) < p.min_sa) { sa.value = p.min_sa; }
		root.querySelector('[data-sa-hint]').textContent = 'Min ' + inr(p.min_sa) + (s0 ? ', in multiples of ' + inr(s0[1]) : '');
		root.querySelector('[data-riders]').innerHTML = riderHtml(p);
	}

	function syncBy() {
		var by = f(form, 'by').value;
		root.querySelector('.a4u-by-sa').hidden = by !== 'sa';
		root.querySelector('.a4u-by-budget').hidden = by !== 'budget';
	}

	// LIC वापरतं तसं "age nearer birthday"
	function ageNearer(dobStr) {
		var dob = new Date(dobStr + 'T00:00:00');
		if (isNaN(dob.getTime())) { return null; }
		var now = new Date();
		var age = now.getFullYear() - dob.getFullYear();
		var lastBd = new Date(dob.getTime());
		lastBd.setFullYear(dob.getFullYear() + age);
		if (lastBd > now) { age--; lastBd.setFullYear(lastBd.getFullYear() - 1); }
		if ((now - lastBd) / 86400000 > 182) { age++; }
		return age;
	}

	function showErr(list) {
		if (!list.length) { errBox.hidden = true; errBox.innerHTML = ''; return; }
		errBox.innerHTML = list.map(esc).join('<br>');
		errBox.hidden = false;
	}

	/* ---------- Rates + engine ---------- */
	function getRates(p) {
		if (!p.has_rates) { return Promise.resolve({}); }
		if (rateCache[p.id]) { return Promise.resolve(rateCache[p.id]); }
		return fetch(api('plan/' + encodeURIComponent(p.id), 'v=' + C.version))
			.then(function (r) { if (!r.ok) { throw new Error('rates'); } return r.json(); })
			.then(function (j) { rateCache[p.id] = j.rates || {}; return rateCache[p.id]; });
	}

	function demoRate(p, age, P, T) {
		if (SINGLE[p.type]) { return 1000 * (0.55 + age * 0.004) * Math.pow(0.975, T || P); }
		return (1000 / P) * (DEMO_FACTOR[p.type] || 1) * (0.9 + age * 0.005);
	}

	// 1D linear interpolation (दोन टोकांच्या बाहेर असल्यास जवळच्या दोन points वरून)
	function interp(pts, x) {
		pts = pts.slice().sort(function (a, b) { return a[0] - b[0]; });
		if (!pts.length) { return null; }
		if (pts.length === 1) { return pts[0][1]; }
		var i = 0;
		while (i < pts.length - 2 && x > pts[i + 1][0]) { i++; }
		var a = pts[i], b = pts[i + 1];
		return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]);
	}
	// sample "key" (term/PPT) वरून interpolation साठी x: regular plans मध्ये premium ≈ 1/PPT
	function sampleX(p, key) {
		if (SINGLE[p.type]) { return key; }
		var tp = resolveTerms(p, 30, key);
		return 1 / tp.P;
	}
	// LIC brochure मधल्या sample premiums वरून tabular rate (per 1000) चा अंदाज
	function sampleRate(p, age, key) {
		if (!p.samples || !p.samples.length || !p.sample_sa) { return null; }
		var adj = SINGLE[p.type] ? 0 : (Number((p.mode_adj || {}).yearly) || 0);
		var cols = {};
		p.samples.forEach(function (s) {
			var r = s[2] / (p.sample_sa / 1000) / (1 + adj / 100); // yearly-mode premium → tabular
			(cols[s[1]] = cols[s[1]] || []).push([s[0], r]);
		});
		var pts = Object.keys(cols).map(function (k) { return [sampleX(p, Number(k)), interp(cols[k], age)]; });
		var v = interp(pts, sampleX(p, key));
		return v && v > 0 ? v : null;
	}

	function npv(r, cf) {
		var s = 0;
		for (var i = 0; i < cf.length; i++) { s += cf[i] / Math.pow(1 + r, i); }
		return s;
	}
	// वार्षिक cash flow वरून IRR (bisection) — XIRR चा अंदाज
	function irr(cf) {
		var lo = -0.99, hi = 1, flo = npv(lo, cf), fhi = npv(hi, cf);
		if (!isFinite(flo) || !isFinite(fhi) || flo * fhi > 0) { return null; }
		for (var k = 0; k < 200; k++) {
			var mid = (lo + hi) / 2, fm = npv(mid, cf);
			if (Math.abs(fm) < 1e-7) { return mid; }
			if (fm * flo > 0) { lo = mid; flo = fm; } else { hi = mid; }
		}
		return (lo + hi) / 2;
	}

	// policy term (T) आणि premium paying term (P)
	function resolveTerms(p, age, sel) {
		switch (p.type) {
			case 'labh': return { T: sel, P: Number(p.ppt_map[sel]) };
			case 'lakshya': return { T: sel, P: sel - 3 };
			case 'umang':
			case 'utsav': return { T: (p.maturity_age || 100) - age, P: sel };
			case 'single': return { T: sel, P: 1 };
			case 'utsav_sp': return { T: (p.maturity_age || 100) - age, P: 1, G: sel };
			default: return { T: sel, P: sel };
		}
	}

	// दिलेल्या SA साठी premium (riders + GST सकट)
	// HSA rebate (Rs. per 1000 BSA) — slab नुसार; 883 साठी वयानुसार table
	function rebatePer1000(p, sa, age) {
		var slabs = p.rebate_slabs || [];
		if (p.rebate_bands && p.rebate_bands.length) {
			slabs = [];
			for (var i = 0; i < p.rebate_bands.length; i++) { if (age <= p.rebate_bands[i][0]) { slabs = p.rebate_bands[i][1]; break; } }
		}
		var r = 0;
		slabs.forEach(function (x) { if (sa >= x[0]) { r = x[1]; } });
		return r;
	}
	function modeAdj(p, mode) {
		var m = p.mode_adj || {};
		return (m[mode] !== undefined) ? Number(m[mode]) : null;
	}
	// S1: rider rate — CSV मध्ये नेमकी ओळ असेल तर ती, नाहीतर flat दर
	function riderRate(k, age, term) {
		var m = C.riderMap || {}, v = m[k + '|' + age + '|' + term];
		return v !== undefined ? Number(v) : Number((C.riderRates || {})[k] || 0);
	}

	// दिलेल्या SA साठी premium (mode rebate/loading + HSA rebate + riders + GST)
	function premiumFor(p, inp, rate, sa, ctx) {
		ctx = ctx || {};
		var single = !!SINGLE[p.type];
		var tabular = rate * sa / 1000;
		var rebate = rebatePer1000(p, sa, inp.age) * sa / 1000;
		var base = Math.max(0, tabular - rebate); // annualised premium (mode loading शिवाय)
		var riders = {}, rTotal = 0, term = ctx.T || inp.term;
		if (inp.r.adb) { riders.adb = riderRate('adb', inp.age, term) * (inp.r.adbSA || sa) / 1000; }
		if (inp.r.addb) { riders.addb = riderRate('addb', inp.age, term) * sa / 1000; }
		if (inp.r.term) { riders.term = riderRate('term', inp.age, term) * (inp.r.termSA || sa) / 1000; }
		if (inp.r.pwb) { riders.pwb = riderRate('pwb', inp.r.pwbAge, ctx.P || term) / 100 * base; }
		Object.keys(riders).forEach(function (k) { rTotal += riders[k]; });
		var g = 1 + inp.gst / 100;
		function yearlyIn(mode) { // त्या mode मध्ये वर्षभरात भरायची रक्कम
			var adj = modeAdj(p, mode);
			if (adj === null) { return (base + rTotal) * (Number(C.modal[mode]) || 1) * MODES[mode][1]; }
			return Math.max(0, tabular * (1 + adj / 100) - rebate) + rTotal * (1 + Math.max(0, adj) / 100);
		}
		if (single) {
			var sp = base * g;
			return { rebate: rebate, tabular: tabular, base: base, riders: riders, inst: sp + rTotal * g, yearPay: sp + rTotal * g, modes: null };
		}
		var modes = Object.keys(MODES).map(function (k) { var y = yearlyIn(k) * g; return [k, y / MODES[k][1], y]; });
		var yp = yearlyIn(inp.mode) * g;
		return { rebate: rebate, tabular: tabular, base: base, riders: riders, inst: yp / MODES[inp.mode][1], yearPay: yp, modes: modes };
	}

	// S3 (v1.4): bonus — term band असल्यास तो, नाहीतर एकच SRB/FAB
	function bonusFor(p, T) {
		var srb = p.srb, fab = T >= p.fab_min_term ? p.fab : 0;
		(p.bonus_bands || []).forEach(function (b) { if (T >= b[0]) { srb = b[1]; fab = b[2]; } });
		return { srb: srb, fab: fab };
	}

	// S7: budget मध्ये बसणारा सगळ्यात मोठा SA (allowed multiple ला round down)
	function solveSA(p, inp, rate) {
		var lo = 0, hi = 1e10;
		for (var k = 0; k < 80; k++) {
			var mid = (lo + hi) / 2;
			if (premiumFor(p, inp, rate, mid).inst <= inp.budget) { lo = mid; } else { hi = mid; }
		}
		var sa = floorToSlab(p, lo), guard = 0;
		while (sa >= p.min_sa && premiumFor(p, inp, rate, sa).inst > inp.budget && guard++ < 50) {
			var s = slabFor(p, sa);
			sa = floorToSlab(p, sa - (s ? s[1] : 1000));
		}
		return sa;
	}

	function compute(p, inp, rates) {
		var age = inp.age, tp = resolveTerms(p, age, inp.term), T = tp.T, P = tp.P, errs = [];
		if (!(age >= p.min_age && age <= p.max_age)) { errs.push('Entry age for this plan must be ' + p.min_age + ' to ' + p.max_age + ' years.'); }
		var minByTerm = p.min_age_by_term ? p.min_age_by_term[inp.term] : undefined;
		if (minByTerm !== undefined && age < minByTerm) { errs.push('For this term the minimum entry age is ' + (minByTerm === 0 ? '30 days' : minByTerm + ' years') + '.'); }
		if (BY_PPT[p.type]) {
			if (p.ppt_max_age_sum && age + P > p.ppt_max_age_sum) { errs.push('Age + premium paying term cannot exceed ' + p.ppt_max_age_sum + '. Choose a shorter term.'); }
		} else {
			if (age + T > p.max_maturity) { errs.push('Maturity age cannot exceed ' + p.max_maturity + ' years. Choose a shorter term.'); }
			if (p.min_maturity && age + T < p.min_maturity) { errs.push('Age at maturity must be at least ' + p.min_maturity + ' years.'); }
		}
		// riders चे नियम (S4)
		if (inp.r.adb && age < 18) { errs.push('Accident Benefit rider is available from age 18.'); }
		if (inp.r.addb && (age < 18 || age > 60)) { errs.push('AD&DB rider is available for age 18 to 60.'); }
		if (inp.r.term && age < 18) { errs.push('Term rider is available from age 18.'); }
		if (inp.r.pwb) {
			if (age >= 18) { errs.push('Premium Waiver rider is for child policies (life assured below 18).'); }
			if (!(inp.r.pwbAge >= 18 && inp.r.pwbAge <= 50)) { errs.push('Proposer / parent age for Premium Waiver rider must be 18 to 50.'); }
			else if (inp.r.pwbAge <= age) { errs.push('Proposer age must be more than the child\'s age.'); }
		}
		if (errs.length) { return { errors: errs }; }

		var key = BY_PPT[p.type] ? P : T;
		if (p.type === 'utsav_sp') { key = inp.term; }
		var rate = rates[age + '|' + key], basis = p.verified ? 'verified' : 'csv';
		if (!rate) {
			rate = sampleRate(p, age, key);
			basis = 'brochure';
			if (!rate) {
				if (p.has_rates) { return { errors: ['Rate is not available for age ' + age + ' with this term. Please contact us for an exact quote.'] }; }
				rate = demoRate(p, age, P, T);
				basis = 'demo';
			}
		}
		var demo = basis !== 'verified';

		var sa = inp.sa;
		if (inp.by === 'budget') {
			sa = solveSA(p, inp, rate);
			if (sa < p.min_sa) {
				return { errors: ['Minimum premium for this plan and term is about ' + inr(premiumFor(p, inp, rate, p.min_sa).inst) + (SINGLE[p.type] ? '' : ' (' + MODES[inp.mode][0] + ')') + '. Please increase your budget.'] };
			}
		}
		var slab = slabFor(p, sa);
		if (!(sa >= p.min_sa) || !slab) { return { errors: ['Minimum Sum Assured for this plan is ' + inr(p.min_sa) + '.'] }; }
		if (sa % slab[1] !== 0) { return { errors: ['Sum Assured must be in multiples of ' + inr(slab[1]) + ' (for example ' + inr(floorToSlab(p, sa)) + ').'] }; }
		if (inp.r.adb && inp.r.adbSA > 3 * sa) { return { errors: ['Accident Benefit rider Sum Assured can be up to 3 × Sum Assured (' + inr(3 * sa) + ').'] }; }
		if (inp.r.term && inp.r.termSA > sa) { return { errors: ['Term rider Sum Assured can be up to the Sum Assured (' + inr(sa) + ').'] }; }

		var G = tp.G || 0;
		var pr = premiumFor(p, inp, rate, sa, { T: T, P: P });
		var bn = bonusFor(p, T);
		var bonusYears = p.type === 'umang' ? P : ((p.type === 'utsav' || p.type === 'utsav_sp') ? 0 : T);
		var bonus = bn.srb * sa / 1000 * bonusYears;
		var fab = bn.fab * sa / 1000;
		var ga = (p.ga_per_1000 || 0) * sa / 1000 * (p.type === 'utsav_sp' ? G : P);
		var hasIncome = p.type === 'umang' || p.type === 'utsav' || p.type === 'utsav_sp';
		var survival = hasIncome ? p.survival_pct * sa / 100 : 0;
		var incomeStart = p.type === 'utsav' ? Math.max(11, P + 3) : (p.type === 'utsav_sp' ? G + 1 : P);
		var flexi = inp.income === 'flexi' && (p.type === 'utsav' || p.type === 'utsav_sp');
		// maturity: 771 मध्ये नाही; 883 मध्ये higher of BSA / 1.25 × tabular SP + GA
		var maturity = 0;
		if (p.type === 'utsav_sp') { maturity = Math.max(sa, 1.25 * pr.tabular) + ga; }
		else if (p.type !== 'utsav') { maturity = sa + bonus + fab; }

		var rows = [], cf = [], cum = 0, totalPrem = 0, totalSurv = 0, flexiBal = 0, y;
		for (y = 0; y <= T; y++) { cf.push(0); }
		for (y = 1; y <= T; y++) {
			var prem = y <= P ? pr.yearPay : 0, ben = 0, inc = 0;
			if (survival && y >= incomeStart && (p.type === 'utsav' ? y <= T : y < T)) { inc = survival; totalSurv += survival; }
			if (flexi) {
				flexiBal = flexiBal * 1.055 + inc; // S5: Flexi — 5.5% ने जमा
				if (y === T) { ben += flexiBal; }
			} else { ben += inc; }
			if (y === T) { ben += maturity; }
			cf[y - 1] -= prem; // premium वर्षाच्या सुरुवातीला
			cf[y] += ben;      // benefit वर्षाच्या शेवटी
			totalPrem += prem;
			cum += ben - prem;
			rows.push([y, age + y, prem, ben, cum]);
		}
		// मृत्यू लाभ (brochure नुसार)
		var deathSA = 0, deathNote = '';
		if (p.type === 'single' || p.type === 'utsav_sp') {
			var mult = 1.25;
			(p.death_sp || []).some(function (d) { if (age <= d[0]) { mult = d[1]; return true; } return false; });
			deathSA = Math.max(sa, mult * (p.type === 'utsav_sp' ? pr.tabular : pr.base));
			if (p.type === 'utsav_sp') { deathNote = 'plus accrued Guaranteed Additions'; }
		} else if (p.type === 'lakshya') {
			deathSA = Math.max(7 * pr.base, (p.death_pct || 110) / 100 * sa);
			deathNote = 'plus 10% of SA every year till maturity (Annual Income Benefit)';
		} else if (p.death_pct > 0) {
			deathSA = Math.max(p.death_pct / 100 * sa, 7 * pr.base);
		}
		var totalBenefit = maturity + (flexi ? flexiBal : totalSurv);
		// S3: दुसरी परिस्थिती — bonus 50% कमी झाला तर
		var cut = 0.5 * (bonus + fab), cfB = cf.slice();
		cfB[T] -= cut;
		return {
			totalBenefitLow: totalBenefit - cut, irrLow: cut ? irr(cfB) : irr(cf), bonusCut: cut,
			plan: p, age: age, sa: sa, T: T, P: P, G: G, mode: SINGLE[p.type] ? 'single' : inp.mode, by: inp.by, gst: inp.gst, r: inp.r, income: flexi ? 'flexi' : 'regular',
			basis: basis, demo: demo, rate: rate, pr: pr, inst: pr.inst, totalPrem: totalPrem, bonus: bonus, fab: fab, ga: ga, srb: bn.srb,
			survival: survival, incomeStart: incomeStart, totalSurv: totalSurv, flexiBal: flexiBal, deathSA: deathSA, deathNote: deathNote,
			maturity: maturity, totalBenefit: totalBenefit, irr: irr(cf), rows: rows
		};
	}

	/* ---------- Result ---------- */
	function modeName(r) { return r.mode === 'single' ? 'Single premium' : MODES[r.mode][0]; }

	function shareUrl(r) {
		var u = new URL(window.location.href);
		u.search = '';
		u.hash = '';
		u.searchParams.set('plan', r.plan.id);
		u.searchParams.set('age', r.age);
		u.searchParams.set('sa', r.sa);
		u.searchParams.set('term', resolveBack(r));
		if (r.mode !== 'single') { u.searchParams.set('mode', r.mode); }
		if (r.income === 'flexi') { u.searchParams.set('income', 'flexi'); }
		return u.toString();
	}
	function resolveBack(r) { return r.plan.type === 'utsav_sp' ? r.G : (BY_PPT[r.plan.type] ? r.P : r.T); }

	function waText(r) {
		return 'Hello, I checked the LIC calculator on advisor4u.in.\n' +
			'Plan: ' + r.plan.name + '\n' +
			'Age: ' + r.age + '\n' +
			'Sum Assured: ' + inr(r.sa) + '\n' +
			'Term: ' + r.T + ' yrs (pay ' + (SINGLE[r.plan.type] ? 'once' : r.P + ' yrs') + ')\n' +
			'Premium: ' + inr(r.inst) + ' (' + modeName(r) + ')\n' +
			'Estimated benefit: ' + inr(r.totalBenefit) + '\n' +
			'Link: ' + shareUrl(r) + '\n' +
			'Please guide me.';
	}

	function pct(x) { return x === null || x === undefined ? '—' : (x * 100).toFixed(2) + '%'; }
	function card(label, value) { return '<div class="a4u-card"><span>' + label + '</span><strong>' + value + '</strong></div>'; }
	function tr(label, value) { return '<tr><th>' + label + '</th><td>' + value + '</td></tr>'; }

	// S2 (v1.2): एकूण भरलेला premium vs एकूण मिळालेला benefit — साधा SVG chart
	function chartSvg(r, c1, c2) {
		var W = 600, H = 220, L = 58, R = 12, T = 14, B = 30;
		var paid = 0, got = 0, a = [], b = [];
		r.rows.forEach(function (x) { paid += x[2]; got += x[3]; a.push(paid); b.push(got); });
		var max = Math.max(paid, got) || 1, n = r.rows.length;
		function px(i) { return L + (n === 1 ? 0 : i * (W - L - R) / (n - 1)); }
		function py(v) { return T + (H - T - B) * (1 - v / max); }
		function line(arr) { return arr.map(function (v, i) { return px(i).toFixed(1) + ',' + py(v).toFixed(1); }).join(' '); }
		function short(v) { return v >= 1e7 ? (v / 1e7).toFixed(1) + 'Cr' : v >= 1e5 ? (v / 1e5).toFixed(1) + 'L' : nf.format(v); }
		var tx = 'font-size="11" fill="#6b7a8e" font-family="Arial,sans-serif"', grid = '';
		[0, 0.5, 1].forEach(function (k) {
			var y = py(max * k);
			grid += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" stroke="#e3ebf6"/><text ' + tx + ' x="' + (L - 6) + '" y="' + (y + 4) + '" text-anchor="end">₹' + short(max * k) + '</text>';
		});
		var step = Math.max(1, Math.ceil(n / 8)), xl = '';
		for (var i = 0; i < n; i += step) { xl += '<text ' + tx + ' x="' + px(i) + '" y="' + (H - 10) + '" text-anchor="middle">' + r.rows[i][0] + '</text>'; }
		return '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Cumulative premium paid versus cumulative benefits received by policy year">' +
			grid + xl + '<polyline fill="none" stroke-width="2.5" stroke-linejoin="round" stroke="' + (c1 || '#0b4ea2') + '" points="' + line(a) + '"/>' +
			'<polyline fill="none" stroke-width="2.5" stroke-linejoin="round" stroke="' + (c2 || '#1f8f4e') + '" points="' + line(b) + '"/></svg>';
	}
	function chart(r) {
		return '<figure class="a4u-chart">' + chartSvg(r) +
			'<figcaption><span class="k paid"></span>Total premium paid <span class="k got"></span>Total benefits received <em>(by policy year)</em></figcaption></figure>';
	}

	function render(r) {
		last = r;
		var p = r.plan, m = modeName(r), h = '', pr = r.pr;
		if (r.mode === 'single') { m = 'Single premium'; }
		if (r.basis === 'brochure') { h += '<div class="a4u-banner a4u-est">Estimated from the sample premiums in the official LIC sales brochure. The actual premium may differ slightly for this age and term.</div>'; }
		else if (r.basis === 'demo') { h += '<div class="a4u-banner">Demo rates — rough figures only. Verified LIC rates for this plan are being updated.</div>'; }
		h += '<h3 class="a4u-rtitle">' + esc(p.name) + ' — Illustration</h3>';
		h += '<p class="a4u-meta">Age ' + r.age + ' · Sum Assured ' + inr(r.sa) + ' · Term ' + r.T + ' yrs · Pay ' + (SINGLE[p.type] ? 'once' : r.P + ' yrs') + ' · ' + m + (r.G ? ' · GA period ' + r.G + ' yrs' : '') + '</p>';
		if (r.by === 'budget') { h += '<p class="a4u-note a4u-ok">Highest Sum Assured within your budget: <b>' + inr(r.sa) + '</b></p>'; }
		h += '<div class="a4u-cards">' +
			card(SINGLE[p.type] ? 'Single premium' : 'Installment (' + m + ')', inr(r.inst)) +
			card('Total premium paid', inr(r.totalPrem)) +
			card(r.totalSurv ? 'Estimated total benefits' : 'Estimated maturity', inr(r.totalBenefit)) +
			card('Return (IRR, approx.)', r.irr === null ? '—' : (r.irr * 100).toFixed(2) + '% p.a.') +
			'</div>';

		// S5: सगळ्या modes चे हप्ते एकाच ठिकाणी
		if (pr.modes) {
			h += '<div class="a4u-scroll a4u-modes"><table><thead><tr><th>Mode</th><th>Installment</th><th>Yearly total</th></tr></thead><tbody>' +
				pr.modes.map(function (x) { return '<tr' + (x[0] === r.mode ? ' class="sel"' : '') + '><td>' + MODES[x[0]][0] + '</td><td>' + inr(x[1]) + '</td><td>' + inr(x[2]) + '</td></tr>'; }).join('') +
				'</tbody></table></div>';
		}

		var rows = tr('Tabular ' + (SINGLE[p.type] ? 'single' : 'annual') + ' premium', inr(pr.tabular)) +
			(pr.rebate ? tr('High Sum Assured rebate', '− ' + inr(pr.rebate)) : '');
		Object.keys(pr.riders).forEach(function (k) { rows += tr(RIDERS[k] + ' (approx., yearly)', inr(pr.riders[k])); });
		rows += tr('GST', r.gst + '%');
		if (r.deathSA) { rows += tr('Sum Assured on death (approx.)' + (r.deathNote ? '<br><small>' + r.deathNote + '</small>' : ''), inr(r.deathSA)); }
		if (p.type === 'utsav_sp') { rows += tr('<b>Guaranteed:</b> Maturity at age ' + (r.age + r.T) + ' (incl. Guaranteed Additions)', inr(r.maturity)); }
		else if (p.type !== 'utsav') { rows += tr('<b>Guaranteed:</b> Basic Sum Assured on maturity', inr(r.sa)); }
		if (r.totalSurv) {
			var incName = p.type === 'umang' ? 'Survival benefit' : (r.income === 'flexi' ? 'Flexi income' : 'Regular income');
			rows += tr('<b>Guaranteed:</b> ' + incName + ' ' + p.survival_pct + '% of SA yearly from year ' + r.incomeStart, inr(r.survival) + ' / yr');
			rows += r.income === 'flexi' ? tr('Flexi income accumulated @ 5.5% till age ' + (r.age + r.T) + ' (if never withdrawn)', inr(r.flexiBal)) : tr('Total income till age ' + (r.age + r.T), inr(r.totalSurv));
		}
		if (r.ga && p.type !== 'utsav_sp') { rows += tr('<b>Guaranteed:</b> Guaranteed Additions accrued (paid on death / surrender)', inr(r.ga)); }
		if (r.bonus) { rows += tr('<b>Non-guaranteed:</b> Simple Reversionary Bonus @ \u20B9' + r.srb + '/1000 (est.)', inr(r.bonus)); }
		if (r.fab) { rows += tr('<b>Non-guaranteed:</b> Final Additional Bonus (est.)', inr(r.fab)); }
		rows += tr(p.type === 'utsav' ? 'Cover till age' : 'Maturity at age', String(r.age + r.T));
		rows += tr('Death benefit is never less than', '105% of premiums paid');
		h += '<table class="a4u-sum"><tbody>' + rows + '</tbody></table>';
		if (r.bonusCut) {
			h += '<div class="a4u-scroll a4u-modes"><table><thead><tr><th>Bonus scenario</th><th>Total benefits</th><th>IRR</th></tr></thead><tbody>' +
				'<tr><td>At current bonus rates</td><td>' + inr(r.totalBenefit) + '</td><td>' + pct(r.irr) + '</td></tr>' +
				'<tr><td>If bonus is 50% lower</td><td>' + inr(r.totalBenefitLow) + '</td><td>' + pct(r.irrLow) + '</td></tr></tbody></table></div>';
		}
		if (p.type === 'anand' && p.tail_age) { h += '<p class="a4u-note">After maturity, life cover equal to Basic Sum Assured continues till age ' + p.tail_age + '.</p>'; }
		if (p.type === 'utsav') { h += '<p class="a4u-note">Whole-life plan with no maturity benefit. Flexi Income lets you withdraw up to 75% of the accumulated amount once a year.</p>'; }
		if (p.type === 'utsav_sp' && r.income === 'flexi') { h += '<p class="a4u-note">Flexi Income lets you withdraw up to 75% of the accumulated amount once a year.</p>'; }
		if (Object.keys(pr.riders).length) { h += '<p class="a4u-note">Rider premiums are approximate averages; actual rider rates depend on age and term.</p>'; }
		if (p.closed) { h += '<p class="a4u-note">This plan is closed for new business — figures are for existing policyholders\' reference only.</p>'; }

		h += chart(r);
		h += '<details class="a4u-years"' + (r.rows.length <= 25 ? ' open' : '') + '><summary>Year-wise cash flow</summary><div class="a4u-scroll"><table>' +
			'<thead><tr><th>Year</th><th>Age</th><th>Premium</th><th>Benefit</th><th>Net (cumulative)</th></tr></thead><tbody>' +
			r.rows.map(function (x) {
				return '<tr><td>' + x[0] + '</td><td>' + x[1] + '</td><td>' + (x[2] ? inr(x[2]) : '—') + '</td><td>' + (x[3] ? inr(x[3]) : '—') + '</td><td class="' + (x[4] < 0 ? 'neg' : 'pos') + '">' + inr(x[4]) + '</td></tr>';
			}).join('') +
			'</tbody></table></div></details>';

		h += '<div class="a4u-actions no-print">' +
			'<button type="button" data-act="present" class="a4u-btn a4u-gold">Create Presentation / PDF</button>' +
			'<button type="button" data-act="print" class="a4u-btn a4u-ghost">Print</button>' +
			'<button type="button" data-act="wa" class="a4u-btn a4u-wa">Share on WhatsApp</button>' +
			'<button type="button" data-act="link" class="a4u-btn a4u-ghost">Copy link</button>' +
			'</div>';

		if (C.plans.length > 1) {
			h += '<div class="a4u-compare no-print"><h4>Compare with another plan</h4>' +
				'<p>Same age, Sum Assured and payment mode (without riders).</p>' +
				'<div class="a4u-row">' +
				field('Plan', '<select data-cmp="plan">' + C.plans.filter(function (x) { return x.id !== p.id; }).map(function (x) { return '<option value="' + esc(x.id) + '">' + esc(x.name) + '</option>'; }).join('') + '</select>') +
				field('<span data-cmp-label>Policy term</span>', '<select data-cmp="term"></select>') +
				'</div>' +
				'<button type="button" data-act="compare" class="a4u-btn a4u-ghost">Compare</button>' +
				'<div class="a4u-cmp-out" aria-live="polite"></div></div>';
		}

		h += '<form class="a4u-lead no-print" novalidate>' +
			'<h4>Want an exact quote?</h4><p>Optional — share your details and our advisor will call you.</p>' +
			'<input type="text" name="name" placeholder="Your name" maxlength="100" autocomplete="name">' +
			'<input type="tel" name="mobile" placeholder="10-digit mobile number" maxlength="14" inputmode="numeric" autocomplete="tel">' +
			'<input type="text" name="company" class="a4u-hp" tabindex="-1" autocomplete="off" aria-hidden="true">' +
			'<label class="a4u-check"><input type="checkbox" name="consent" value="1"> I agree to be contacted by Sahare Financial Services about this enquiry.</label>' +
			'<button type="submit" class="a4u-btn">Send to Advisor</button>' +
			'<p class="a4u-lead-msg" role="status"></p>' +
			'</form>';

		if (C.links && C.links.length) {
			h += '<p class="a4u-links no-print">' + C.links.map(function (l) { return '<a href="' + esc(l.url) + '">' + esc(l.label) + '</a>'; }).join(' · ') + '</p>';
		}
		h += '<p class="a4u-foot">Rate version v' + C.version + (p.effective ? ' (effective ' + esc(p.effective) + ')' : '') +
			(p.brochure ? ' · <a href="' + esc(p.brochure) + '" target="_blank" rel="noopener">Official LIC brochure</a>' : '') +
			' · Calculated on ' + new Date().toLocaleDateString('en-IN') + '<br>' +
			'For education only. This is not an official LIC quotation and is not provided by LIC of India. Bonus figures are not guaranteed. Please verify with the policy document before buying.</p>';

		result.innerHTML = h;
		result.hidden = false;
		lastCmp = null;
		var cp = result.querySelector('[data-cmp="plan"]');
		if (cp) { cp.addEventListener('change', fillCmpTerms); fillCmpTerms(); }
		result.scrollIntoView({ behavior: 'smooth', block: 'start' });
	}

	/* ---------- Compare ---------- */
	function fillCmpTerms() {
		var ps = result.querySelector('[data-cmp="plan"]'), ts = result.querySelector('[data-cmp="term"]');
		var p2 = planById(ps.value), want = last ? resolveBack(last) : 0;
		ts.innerHTML = p2.terms.map(function (t) { return '<option value="' + t + '">' + termText(p2, t) + '</option>'; }).join('');
		if (p2.terms.indexOf(want) > -1) { ts.value = want; }
		result.querySelector('[data-cmp-label]').textContent = termLabel(p2);
	}

	function runCompare() {
		var a = last, out = result.querySelector('.a4u-cmp-out');
		var p2 = planById(result.querySelector('[data-cmp="plan"]').value);
		var inp = { age: a.age, by: 'sa', sa: floorToSlab(p2, Math.max(a.sa, p2.min_sa)), term: parseInt(result.querySelector('[data-cmp="term"]').value, 10), mode: a.mode === 'single' ? 'yearly' : a.mode, gst: a.gst, income: 'regular', r: {} };
		out.innerHTML = '<p class="a4u-note">Calculating…</p>';
		getRates(p2).then(function (rates) {
			var b = compute(p2, inp, rates);
			if (b.errors) { out.innerHTML = '<div class="a4u-error">' + b.errors.map(esc).join('<br>') + '</div>'; return; }
			lastCmp = { a: a, b: b };
			var rowsC = [
				['Sum Assured', function (x) { return inr(x.sa); }],
				['Term / Pay', function (x) { return x.T + ' / ' + (SINGLE[x.plan.type] ? 'once' : x.P + ' yrs'); }],
				['Premium', function (x) { return inr(x.inst) + ' <small>(' + modeName(x) + ')</small>'; }],
				['Total premium paid', function (x) { return inr(x.totalPrem); }],
				['Guaranteed benefits', function (x) { return inr((x.plan.type === 'utsav' ? 0 : (x.plan.type === 'utsav_sp' ? x.maturity : x.sa)) + x.totalSurv); }],
				['Non-guaranteed bonus (est.)', function (x) { return inr(x.bonus + x.fab); }],
				['Estimated total benefits', function (x) { return inr(x.totalBenefit); }],
				['Return (IRR, approx.)', function (x) { return x.irr === null ? '—' : (x.irr * 100).toFixed(2) + '%'; }],
				['Last payout at age', function (x) { return String(x.age + x.T); }]
			];
			out.innerHTML = (b.demo || a.demo ? '<div class="a4u-banner a4u-est">One or both plans use estimated (not verified) rates.</div>' : '') +
				'<div class="a4u-scroll"><table class="a4u-cmp"><thead><tr><th></th><th>' + esc(a.plan.name) + '</th><th>' + esc(p2.name) + '</th></tr></thead><tbody>' +
				rowsC.map(function (c) { return '<tr><th>' + c[0] + '</th><td>' + c[1](a) + '</td><td>' + c[1](b) + '</td></tr>'; }).join('') +
				'</tbody></table></div>';
			track('compare');
		}).catch(function () { out.innerHTML = '<div class="a4u-error">Could not load rates. Please try again.</div>'; });
	}

	/* ---------- v2.0: Branded presentation + PDF ---------- */
	var BR = C.brand || {};
	var GOLD = BR.gold || '#B8924A', GREEN = BR.green || '#3F5A22';
	var lang = 'en', clientName = '';
	var I18N = {
		en: {
			ill: 'Benefit Illustration', pfor: 'Prepared for', pon: 'Prepared on', pby: 'Presented by', details: 'Your plan details',
			age: 'Age', sa: 'Basic Sum Assured', term: 'Policy term', ppt: 'Premium paying term', gap: 'Guaranteed Addition period', mode: 'Payment mode', yrs: 'years', once: 'Single premium',
			glance: 'Plan at a glance', inst: 'Installment', tprem: 'Total premium payable', tben: 'Estimated total benefits', irr: 'Return (IRR, approx.)',
			bymode: 'Premium by payment mode', ytot: 'Yearly total', pdet: 'Premium details', tab: 'Tabular premium', hsa: 'High Sum Assured rebate', rider: 'Riders', gst: 'GST',
			ben: 'Benefits', g: 'Guaranteed', ng: 'Non-guaranteed', bsa: 'Basic Sum Assured on maturity', surv: 'Survival / income benefit', ga: 'Guaranteed Additions',
			srb: 'Simple Reversionary Bonus (est.)', fab: 'Final Additional Bonus (est.)', death: 'Sum Assured on death (approx.)', matage: 'Maturity at age', cover: 'Life cover till age',
			scen: 'Bonus scenarios', sc1: 'At current bonus rates', sc2: 'If bonus is 50% lower', chart: 'Premium paid vs benefits received', paid: 'Total premium paid', got: 'Total benefits received',
			insight: 'You pay {p} and are estimated to receive {b} — about {x} times your premium.',
			yw: 'Year-wise cash flow', yr: 'Year', prem: 'Premium', bene: 'Benefit', net: 'Net (cumulative)', cmp: 'Plan comparison', notes: 'Important notes',
			contact: 'Talk to your advisor', scan: 'Scan to chat on WhatsApp', page: 'Page', of: 'of', est: 'Premium estimated from LIC published sample premiums.',
			d1: 'This is an illustration for understanding only and is not a policy contract. The final premium and benefits will be as per LIC\'s quotation and benefit illustration at the time of proposal.',
			d2: 'Bonuses are not guaranteed. LIC declares bonus rates every year based on its experience; the figures above assume the bonus rates shown.',
			d3: 'Please read the LIC sales brochure (Plan {no}, UIN {uin}) carefully before concluding a sale.',
			d4: 'Tax benefits, if any, are as per prevailing tax laws and may change.',
			solicit: 'Insurance is the subject matter of solicitation.'
		},
		mr: {
			ill: 'लाभांचे उदाहरण (Benefit Illustration)', pfor: 'यांच्यासाठी', pon: 'दिनांक', pby: 'सादरकर्ते', details: 'तुमच्या योजनेचा तपशील',
			age: 'वय', sa: 'मूळ विमा रक्कम', term: 'पॉलिसी मुदत', ppt: 'हप्ता भरण्याची मुदत', gap: 'हमी वाढ (GA) कालावधी', mode: 'हप्त्याचा प्रकार', yrs: 'वर्षे', once: 'एकरकमी हप्ता',
			glance: 'योजना एका नजरेत', inst: 'हप्ता', tprem: 'एकूण भरायचा हप्ता', tben: 'अंदाजे एकूण लाभ', irr: 'परतावा (IRR, अंदाजे)',
			bymode: 'हप्त्याच्या प्रकारानुसार रक्कम', ytot: 'वर्षाची एकूण रक्कम', pdet: 'हप्त्याचा तपशील', tab: 'मूळ (tabular) हप्ता', hsa: 'जास्त विमा रकमेवरील सूट', rider: 'रायडर', gst: 'GST',
			ben: 'लाभ', g: 'हमी असलेले', ng: 'हमी नसलेले', bsa: 'मुदतपूर्तीला मूळ विमा रक्कम', surv: 'हयातीचा / उत्पन्न लाभ', ga: 'हमी वाढ (Guaranteed Additions)',
			srb: 'साधा बोनस (अंदाजे)', fab: 'अंतिम अतिरिक्त बोनस (अंदाजे)', death: 'मृत्यू झाल्यास विमा रक्कम (अंदाजे)', matage: 'मुदतपूर्ती वय', cover: 'विमा संरक्षण या वयापर्यंत',
			scen: 'बोनसच्या दोन परिस्थिती', sc1: 'सध्याच्या बोनस दराने', sc2: 'बोनस 50% कमी झाल्यास', chart: 'भरलेला हप्ता विरुद्ध मिळालेला लाभ', paid: 'एकूण भरलेला हप्ता', got: 'एकूण मिळालेला लाभ',
			insight: 'तुम्ही {p} भरता आणि अंदाजे {b} मिळतात — म्हणजे हप्त्याच्या साधारण {x} पट.',
			yw: 'वर्षवार रोख प्रवाह', yr: 'वर्ष', prem: 'हप्ता', bene: 'लाभ', net: 'निव्वळ (एकूण)', cmp: 'योजनांची तुलना', notes: 'महत्त्वाच्या सूचना',
			contact: 'तुमच्या सल्लागाराशी बोला', scan: 'WhatsApp वर बोलण्यासाठी scan करा', page: 'पान', of: 'पैकी', est: 'हप्ता LIC ने प्रसिद्ध केलेल्या नमुना हप्त्यांवरून अंदाजे काढला आहे.',
			d1: 'हे फक्त समजण्यासाठी दिलेले उदाहरण आहे, पॉलिसीचा करार नाही. अंतिम हप्ता व लाभ प्रस्तावाच्या वेळी LIC च्या quotation आणि benefit illustration नुसार असतील.',
			d2: 'बोनसची हमी नाही. LIC दरवर्षी आपल्या अनुभवानुसार बोनस दर जाहीर करते; वरील आकडे दाखवलेल्या बोनस दरांवर आधारित आहेत.',
			d3: 'विक्रीपूर्वी LIC चे sales brochure (Plan {no}, UIN {uin}) काळजीपूर्वक वाचा.',
			d4: 'कर सवलती (असल्यास) सध्याच्या कर कायद्यानुसार आहेत आणि बदलू शकतात.',
			solicit: 'Insurance is the subject matter of solicitation. (विमा हा विनंतीचा विषय आहे.)'
		}
	};
	function tt(k) { return (I18N[lang] && I18N[lang][k]) || I18N.en[k] || k; }
	function fmtT(k, map) { return tt(k).replace(/\{(\w+)\}/g, function (m, n) { return map[n] !== undefined ? map[n] : m; }); }

	var scriptCache = {};
	function loadScript(src) {
		if (!scriptCache[src]) {
			scriptCache[src] = new Promise(function (res, rej) {
				var s = document.createElement('script');
				s.src = src; s.async = true;
				s.onload = res; s.onerror = function () { delete scriptCache[src]; rej(new Error('load ' + src)); };
				document.head.appendChild(s);
			});
		}
		return scriptCache[src];
	}
	function vendor(file) { return loadScript((C.vendor || '') + file + '?v=' + C.version); }

	function qrImg(text) {
		try {
			var q = window.qrcode(0, 'M');
			q.addData(text);
			q.make();
			return q.createDataURL(4, 2);
		} catch (e) { return ''; }
	}

	function waLink(r) {
		var msg = 'Hello, I saw the LIC ' + r.plan.name + ' illustration (Age ' + r.age + ', SA ' + inr(r.sa) + '). Please call me.';
		return 'https://wa.me/' + C.whatsapp + '?text=' + encodeURIComponent(msg);
	}

	function pageWrap(inner, r, n, total) {
		var p = r.plan;
		return '<div class="a4p">' +
			'<div class="a4p-head"><img src="' + esc(BR.logo || '') + '" alt="" crossorigin="anonymous"><div><b>' + esc(BR.name || '') + '</b><span>' + esc(BR.web || '') + ' · ' + esc(BR.phone || '') + '</span></div></div>' +
			'<div class="a4p-body">' + inner + '</div>' +
			'<div class="a4p-foot"><div>' + esc(BR.agent || '') + (BR.type ? ', ' + esc(BR.type) : '') + (BR.code ? ' · Agency Code: ' + esc(BR.code) : '') + (BR.branch ? ' · Branch: ' + esc(BR.branch) : '') + '</div>' +
			'<div>LIC ' + esc(p.name) + (p.uin ? ' · UIN ' + esc(p.uin) : '') + ' · ' + esc(tt('solicit')) + '</div>' +
			'<div class="a4p-pn">' + tt('page') + ' ' + n + ' ' + tt('of') + ' ' + total + '</div></div></div>';
	}

	function kv(label, val) { return '<tr><th>' + label + '</th><td>' + val + '</td></tr>'; }

	function buildPages(r) {
		var p = r.plan, pr = r.pr, single = !!SINGLE[p.type], pages = [];
		var termLbl = p.type === 'utsav_sp' ? tt('gap') : tt('term');
		var termVal = (p.type === 'utsav_sp' ? r.G : r.T) + ' ' + tt('yrs');
		var mName = single ? tt('once') : MODES[r.mode][0];
		var today = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
		var qr = qrImg(waLink(r));

		// 1. Cover
		pages.push('<div class="a4p-cover"><img class="a4p-logo" src="' + esc(BR.logo || '') + '" alt="" crossorigin="anonymous">' +
			'<div class="a4p-brand">' + esc(BR.name || '') + '</div>' +
			'<div class="a4p-rule"></div>' +
			'<h1>LIC ' + esc(p.name) + '</h1><h2>' + tt('ill') + '</h2>' +
			(clientName ? '<p class="a4p-for">' + tt('pfor') + ': <b>' + esc(clientName) + '</b></p>' : '') +
			'<p class="a4p-date">' + tt('pon') + ': ' + today + '</p></div>' +
			'<div class="a4p-card"><h3>' + tt('details') + '</h3><table class="a4p-kv">' +
			kv(tt('age'), r.age + ' ' + tt('yrs')) + kv(tt('sa'), inr(r.sa)) + kv(termLbl, termVal) +
			(single ? '' : kv(tt('ppt'), r.P + ' ' + tt('yrs'))) + kv(tt('mode'), mName) +
			kv(single ? tt('once') : tt('inst'), '<b>' + inr(r.inst) + '</b>') + '</table></div>' +
			'<div class="a4p-card a4p-advisor"><div><h3>' + tt('pby') + '</h3><p><b>' + esc(BR.agent || '') + '</b><br>' + esc(BR.type || '') +
			(BR.code ? '<br>Agency Code: ' + esc(BR.code) : '') + '<br>' + esc(BR.phone || '') + ' · ' + esc(BR.email || '') + '<br>' + esc(BR.web || '') + '</p></div>' +
			(qr ? '<div class="a4p-qr"><img src="' + qr + '" alt=""><span>' + tt('scan') + '</span></div>' : '') + '</div>');

		// 2. Plan at a glance
		var g = '<h2 class="a4p-h">' + tt('glance') + '</h2><div class="a4p-cards">' +
			'<div><span>' + (single ? tt('once') : tt('inst') + ' (' + mName + ')') + '</span><b>' + inr(r.inst) + '</b></div>' +
			'<div><span>' + tt('tprem') + '</span><b>' + inr(r.totalPrem) + '</b></div>' +
			'<div><span>' + tt('tben') + '</span><b>' + inr(r.totalBenefit) + '</b></div>' +
			'<div><span>' + tt('irr') + '</span><b>' + pct(r.irr) + '</b></div></div>';
		if (pr.modes) {
			g += '<h3>' + tt('bymode') + '</h3><table class="a4p-t"><thead><tr><th>' + tt('mode') + '</th><th>' + tt('inst') + '</th><th>' + tt('ytot') + '</th></tr></thead><tbody>' +
				pr.modes.map(function (x) { return '<tr' + (x[0] === r.mode ? ' class="sel"' : '') + '><td>' + MODES[x[0]][0] + '</td><td>' + inr(x[1]) + '</td><td>' + inr(x[2]) + '</td></tr>'; }).join('') + '</tbody></table>';
		}
		var rid = 0;
		Object.keys(pr.riders).forEach(function (k) { rid += pr.riders[k]; });
		g += '<h3>' + tt('pdet') + '</h3><table class="a4p-t a4p-kv2"><tbody>' + kv(tt('tab'), inr(pr.tabular)) +
			(pr.rebate ? kv(tt('hsa'), '− ' + inr(pr.rebate)) : '') + (rid ? kv(tt('rider'), inr(rid)) : '') + kv(tt('gst'), r.gst + '%') + '</tbody></table>';
		g += '<h3>' + tt('ben') + '</h3><table class="a4p-t a4p-kv2"><tbody>';
		if (p.type === 'utsav_sp') { g += kv('<i class="tg">' + tt('g') + '</i> ' + tt('matage') + ' ' + (r.age + r.T), inr(r.maturity)); }
		else if (p.type !== 'utsav') { g += kv('<i class="tg">' + tt('g') + '</i> ' + tt('bsa'), inr(r.sa)); }
		if (r.totalSurv) { g += kv('<i class="tg">' + tt('g') + '</i> ' + tt('surv') + ' (' + p.survival_pct + '% × SA)', inr(r.survival) + ' / yr'); }
		if (r.ga && p.type !== 'utsav_sp') { g += kv('<i class="tg">' + tt('g') + '</i> ' + tt('ga'), inr(r.ga)); }
		if (r.bonus) { g += kv('<i class="tn">' + tt('ng') + '</i> ' + tt('srb'), inr(r.bonus)); }
		if (r.fab) { g += kv('<i class="tn">' + tt('ng') + '</i> ' + tt('fab'), inr(r.fab)); }
		if (r.deathSA) { g += kv(tt('death'), inr(r.deathSA)); }
		g += kv(p.type === 'utsav' ? tt('cover') : tt('matage'), String(r.age + r.T)) + '</tbody></table>';
		if (r.basis !== 'verified') { g += '<p class="a4p-note">' + tt('est') + '</p>'; }
		pages.push(g);

		// 3. Scenarios + chart
		var c = '<h2 class="a4p-h">' + tt('scen') + '</h2><table class="a4p-t"><thead><tr><th></th><th>' + tt('tben') + '</th><th>' + tt('irr') + '</th></tr></thead><tbody>' +
			'<tr><td>' + tt('sc1') + '</td><td>' + inr(r.totalBenefit) + '</td><td>' + pct(r.irr) + '</td></tr>' +
			(r.bonusCut ? '<tr><td>' + tt('sc2') + '</td><td>' + inr(r.totalBenefitLow) + '</td><td>' + pct(r.irrLow) + '</td></tr>' : '') + '</tbody></table>';
		c += '<h3>' + tt('chart') + '</h3><img class="a4p-chart" src="data:image/svg+xml;charset=utf-8,' + encodeURIComponent(chartSvg(r, GREEN, GOLD)) + '" alt="">' +
			'<p class="a4p-legend"><span style="background:' + GREEN + '"></span>' + tt('paid') + ' <span style="background:' + GOLD + '"></span>' + tt('got') + '</p>';
		if (r.totalPrem > 0) {
			c += '<div class="a4p-insight">' + fmtT('insight', { p: inr(r.totalPrem), b: inr(r.totalBenefit), x: (r.totalBenefit / r.totalPrem).toFixed(2) }) + '</div>';
		}
		pages.push(c);

		// 4+. Year-wise (एका पानावर 34 ओळी)
		var per = 34;
		for (var i = 0; i < r.rows.length; i += per) {
			pages.push('<h2 class="a4p-h">' + tt('yw') + (r.rows.length > per ? ' (' + (i / per + 1) + ')' : '') + '</h2><table class="a4p-t a4p-yw"><thead><tr><th>' + tt('yr') + '</th><th>' + tt('age') + '</th><th>' + tt('prem') + '</th><th>' + tt('bene') + '</th><th>' + tt('net') + '</th></tr></thead><tbody>' +
				r.rows.slice(i, i + per).map(function (x) {
					return '<tr><td>' + x[0] + '</td><td>' + x[1] + '</td><td>' + (x[2] ? inr(x[2]) : '—') + '</td><td>' + (x[3] ? inr(x[3]) : '—') + '</td><td class="' + (x[4] < 0 ? 'neg' : 'pos') + '">' + inr(x[4]) + '</td></tr>';
				}).join('') + '</tbody></table>');
		}

		// Last: compare + notes + contact
		var l = '';
		if (lastCmp && lastCmp.a === r) {
			var b = lastCmp.b;
			var rowsC = [[tt('sa'), function (x) { return inr(x.sa); }], [tt('term') + ' / ' + tt('ppt'), function (x) { return x.T + ' / ' + (SINGLE[x.plan.type] ? '1' : x.P); }],
				[tt('inst'), function (x) { return inr(x.inst); }], [tt('tprem'), function (x) { return inr(x.totalPrem); }], [tt('tben'), function (x) { return inr(x.totalBenefit); }],
				[tt('sc2'), function (x) { return inr(x.totalBenefitLow); }], [tt('irr'), function (x) { return pct(x.irr); }]];
			l += '<h2 class="a4p-h">' + tt('cmp') + '</h2><table class="a4p-t"><thead><tr><th></th><th>' + esc(r.plan.name) + '</th><th>' + esc(b.plan.name) + '</th></tr></thead><tbody>' +
				rowsC.map(function (q) { return '<tr><td>' + q[0] + '</td><td>' + q[1](r) + '</td><td>' + q[1](b) + '</td></tr>'; }).join('') + '</tbody></table>';
		}
		l += '<h2 class="a4p-h">' + tt('notes') + '</h2><ol class="a4p-notes"><li>' + tt('d1') + '</li><li>' + tt('d2') + '</li><li>' + fmtT('d3', { no: p.id, uin: p.uin || '—' }) + '</li><li>' + tt('d4') + '</li></ol>';
		l += '<div class="a4p-card a4p-advisor"><div><h3>' + tt('contact') + '</h3><p><b>' + esc(BR.agent || '') + '</b> · ' + esc(BR.name || '') + '<br>' + esc(BR.type || '') +
			(BR.code ? '<br>Agency Code: ' + esc(BR.code) + (BR.branch ? ' · Branch: ' + esc(BR.branch) : '') : '') + '<br>' + esc(BR.phone || '') + ' · ' + esc(BR.email || '') + '<br>' + esc(BR.web || '') + '</p></div>' +
			(qr ? '<div class="a4p-qr"><img src="' + qr + '" alt=""><span>' + tt('scan') + '</span></div>' : '') + '</div>';
		pages.push(l);

		return pages.map(function (inner, k) { return pageWrap(inner, r, k + 1, pages.length); }).join('');
	}

	var modal = null;
	function closePresentation() { if (modal) { modal.remove(); modal = null; document.documentElement.classList.remove('a4u-noscroll'); } }

	function fitPreview() {
		if (!modal) { return; }
		var box = modal.querySelector('.a4u-pv-pages'), w = box.clientWidth - 24, s = Math.min(1, w / 794);
		box.style.setProperty('--s', s);
		Array.prototype.forEach.call(box.querySelectorAll('.a4u-pv-slot'), function (slot) { slot.style.width = (794 * s) + 'px'; slot.style.height = (1123 * s) + 'px'; });
	}

	function renderPreview() {
		var box = modal.querySelector('.a4u-pv-pages');
		var tmp = document.createElement('div');
		tmp.innerHTML = buildPages(last);
		box.innerHTML = '';
		Array.prototype.forEach.call(tmp.children, function (pg) {
			var slot = document.createElement('div');
			slot.className = 'a4u-pv-slot';
			slot.appendChild(pg);
			box.appendChild(slot);
		});
		fitPreview();
	}

	function openPresentation() {
		if (!last) { return; }
		vendor('qrcode.js').catch(function () {}).then(function () {
			closePresentation();
			modal = document.createElement('div');
			modal.className = 'a4u-pv a4u-lic';
			modal.style.setProperty('--gold', GOLD);
			modal.style.setProperty('--green', GREEN);
			modal.innerHTML = '<div class="a4u-pv-bar">' +
				'<select data-pv="lang" aria-label="Language"><option value="en">English</option><option value="mr">मराठी</option></select>' +
				(C.advisor ? '<input data-pv="client" type="text" maxlength="60" placeholder="Client name (optional)" value="' + esc(clientName) + '">' : '') +
				'<button type="button" data-pv="pdf" class="a4u-btn a4u-gold">Download PDF</button>' +
				'<button type="button" data-pv="share" class="a4u-btn a4u-wa">Share</button>' +
				'<button type="button" data-pv="close" class="a4u-btn a4u-ghost" aria-label="Close">✕</button>' +
				'<span data-pv="msg" class="a4u-pv-msg" role="status"></span></div>' +
				'<div class="a4u-pv-pages"></div>';
			document.body.appendChild(modal);
			document.documentElement.classList.add('a4u-noscroll');
			modal.querySelector('[data-pv="lang"]').value = lang;
			renderPreview();
			modal.addEventListener('click', onPvClick);
			modal.querySelector('[data-pv="lang"]').addEventListener('change', function () { lang = this.value; renderPreview(); });
			var cn = modal.querySelector('[data-pv="client"]');
			if (cn) { cn.addEventListener('change', function () { clientName = this.value.trim(); renderPreview(); }); }
		});
	}
	window.addEventListener('resize', fitPreview);
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closePresentation(); } });

	function pvMsg(t) { var m = modal && modal.querySelector('[data-pv="msg"]'); if (m) { m.textContent = t; } }

	function fileName(r) {
		var who = (clientName || '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '');
		return 'LIC-' + r.plan.id + '-Illustration' + (who ? '-' + who : '') + '.pdf';
	}

	// प्रत्येक A4 पान html2canvas ने image करून jsPDF मध्ये — मराठी अक्षरंही बरोबर दिसतात
	function makePdf() {
		var r = last;
		return Promise.all([vendor('html2canvas.min.js'), vendor('jspdf.umd.min.js'), vendor('qrcode.js')]).then(function () {
			var host = document.createElement('div');
			host.className = 'a4u-pdf-host a4u-lic';
			host.style.setProperty('--gold', GOLD);
			host.style.setProperty('--green', GREEN);
			host.innerHTML = buildPages(r);
			document.body.appendChild(host);
			var imgs = host.querySelectorAll('img');
			var ready = Array.prototype.map.call(imgs, function (im) {
				return im.complete ? Promise.resolve() : new Promise(function (res) { im.onload = im.onerror = res; });
			});
			return Promise.all(ready).then(function () {
				var pdf = new window.jspdf.jsPDF({ unit: 'mm', format: 'a4', compress: true });
				var pages = host.querySelectorAll('.a4p'), chain = Promise.resolve();
				Array.prototype.forEach.call(pages, function (pg, i) {
					chain = chain.then(function () {
						pvMsg('Creating page ' + (i + 1) + ' of ' + pages.length + '…');
						return window.html2canvas(pg, { scale: 1.6, backgroundColor: '#ffffff', useCORS: true, logging: false, windowWidth: 794 }).then(function (cv) {
							if (i) { pdf.addPage(); }
							pdf.addImage(cv.toDataURL('image/jpeg', 0.86), 'JPEG', 0, 0, 210, 297);
						});
					});
				});
				return chain.then(function () {
					host.remove();
					pdf.setProperties({ title: 'LIC ' + r.plan.name + ' - Benefit Illustration', author: BR.name || '', subject: 'Illustration', creator: 'A4U LIC Calculator' });
					return pdf.output('blob');
				});
			}).catch(function (e) { host.remove(); throw e; });
		});
	}

	function onPvClick(e) {
		var b = e.target.closest('[data-pv]');
		if (!b) { return; }
		var act = b.getAttribute('data-pv');
		if (act === 'close') { closePresentation(); return; }
		if (act !== 'pdf' && act !== 'share') { return; }
		var btns = modal.querySelectorAll('button');
		Array.prototype.forEach.call(btns, function (x) { x.disabled = true; });
		makePdf().then(function (blob) {
			var name = fileName(last);
			track('pdf');
			var file = window.File ? new File([blob], name, { type: 'application/pdf' }) : null;
			if (act === 'share' && file && navigator.canShare && navigator.canShare({ files: [file] })) {
				return navigator.share({ files: [file], title: 'LIC ' + last.plan.name + ' illustration' }).then(function () { pvMsg('Shared.'); }, function () { pvMsg(''); });
			}
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = name;
			document.body.appendChild(a);
			a.click();
			setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
			pvMsg(act === 'share' ? 'Sharing is not supported here — PDF downloaded instead.' : 'PDF downloaded.');
		}).catch(function () {
			pvMsg('Could not create the PDF. Please try again or use Print.');
		}).then(function () {
			if (modal) { Array.prototype.forEach.call(modal.querySelectorAll('button'), function (x) { x.disabled = false; }); }
		});
	}

	/* ---------- Events ---------- */
	function num(name) { var el = f(form, name); return el ? parseInt(el.value, 10) : NaN; }
	function chk(name) { var el = f(form, name); return !!(el && el.checked); }

	function readInputs() {
		var dob = f(form, 'dob').value;
		var age = dob ? ageNearer(dob) : parseInt(f(form, 'age').value, 10);
		if (dob && age !== null) { f(form, 'age').value = age; }
		var mode = f(form, 'mode').value;
		return {
			age: age,
			by: f(form, 'by').value,
			sa: num('sa'),
			budget: num('budget'),
			term: num('term'),
			mode: MODES[mode] ? mode : 'yearly',
			income: f(form, 'income').value,
			gst: Math.min(28, Math.max(0, parseFloat(f(form, 'gst').value) || 0)),
			r: {
				adb: chk('r_adb'), adbSA: num('r_adb_sa') || 0,
				addb: chk('r_addb'),
				term: chk('r_term'), termSA: num('r_term_sa') || 0,
				pwb: chk('r_pwb'), pwbAge: num('r_pwb_age')
			}
		};
	}

	function run(doTrack) {
		var p = planById(f(form, 'plan').value);
		var inp = readInputs();
		showErr([]);
		if (inp.age === null || isNaN(inp.age)) { showErr(['Please enter date of birth or age.']); return; }
		if (inp.by === 'sa' && isNaN(inp.sa)) { showErr(['Please enter Sum Assured.']); return; }
		if (inp.by === 'budget' && !(inp.budget > 0)) { showErr(['Please enter your premium budget.']); return; }

		calcBtn.disabled = true;
		calcBtn.textContent = 'Calculating…';
		getRates(p)
			.then(function (rates) {
				var r = compute(p, inp, rates);
				if (r.errors) { showErr(r.errors); return; }
				if (inp.by === 'budget') { f(form, 'sa').value = r.sa; }
				render(r);
				if (doTrack) { track('calculate'); }
			})
			.catch(function () { showErr(['Could not load rates. Please check your internet connection and try again.']); })
			.then(function () { calcBtn.disabled = false; calcBtn.textContent = 'Calculate'; });
	}

	f(form, 'plan').addEventListener('change', fillPlanUI);
	Array.prototype.forEach.call(form.querySelectorAll('input[name="by"]'), function (el) { el.addEventListener('change', syncBy); });
	f(form, 'dob').addEventListener('change', function () {
		var a = ageNearer(this.value);
		if (a !== null) { f(form, 'age').value = a; }
	});
	f(form, 'age').addEventListener('input', function () { f(form, 'dob').value = ''; });
	form.addEventListener('submit', function (e) { e.preventDefault(); run(true); });

	result.addEventListener('click', function (e) {
		var b = e.target.closest('[data-act]');
		if (!b || !last) { return; }
		var act = b.getAttribute('data-act');
		if (act === 'print') {
			var d = result.querySelector('.a4u-years');
			if (d) { d.open = true; }
			track('pdf');
			window.print();
		} else if (act === 'wa') {
			track('whatsapp');
			window.open('https://wa.me/' + encodeURIComponent(C.whatsapp) + '?text=' + encodeURIComponent(waText(last)), '_blank', 'noopener');
		} else if (act === 'present') {
			openPresentation();
		} else if (act === 'compare') {
			runCompare();
		} else if (act === 'link') {
			var url = shareUrl(last);
			var done = function () { b.textContent = 'Link copied!'; setTimeout(function () { b.textContent = 'Copy link'; }, 2000); };
			if (navigator.clipboard) { navigator.clipboard.writeText(url).then(done, function () { window.prompt('Copy this link:', url); }); }
			else { window.prompt('Copy this link:', url); }
		}
	});

	// opt-in lead (consent असल्यासच)
	result.addEventListener('submit', function (e) {
		var lf = e.target;
		if (!lf.classList.contains('a4u-lead')) { return; }
		e.preventDefault();
		var msg = lf.querySelector('.a4u-lead-msg');
		var name = f(lf, 'name').value.trim();
		var mobile = f(lf, 'mobile').value.replace(/\D/g, '').replace(/^91(?=\d{10}$)/, '');
		if (!name || !/^[6-9]\d{9}$/.test(mobile) || !f(lf, 'consent').checked) {
			msg.textContent = 'Please enter your name, a valid 10-digit mobile number and tick the consent box.';
			msg.className = 'a4u-lead-msg err';
			return;
		}
		var btn = lf.querySelector('button');
		btn.disabled = true;
		post('lead', { name: name, mobile: mobile, consent: 1, company: f(lf, 'company').value, plan: last.plan.name, sa: last.sa, premium: Math.round(last.inst) })
			.then(function (res) { return res.json().then(function (j) { return { ok: res.ok, j: j }; }); })
			.then(function (o) {
				msg.textContent = o.j && o.j.message ? o.j.message : (o.ok ? 'Thank you!' : 'Something went wrong. Please try WhatsApp.');
				msg.className = 'a4u-lead-msg ' + (o.ok ? 'ok' : 'err');
				if (o.ok) { lf.reset(); }
			})
			.catch(function () { msg.textContent = 'Network error. Please try WhatsApp instead.'; msg.className = 'a4u-lead-msg err'; })
			.then(function () { btn.disabled = false; });
	});

	/* ---------- URL prefill + per-plan page (S8) ---------- */
	(function prefill() {
		var q = new URLSearchParams(window.location.search);
		var pid = q.get('plan') || C.initPlan;
		if (pid && planById(pid)) { f(form, 'plan').value = pid; }
		fillPlanUI();
		syncBy();
		if (!q.get('plan')) { return; }
		var age = parseInt(q.get('age'), 10), sa = parseInt(q.get('sa'), 10), term = parseInt(q.get('term'), 10);
		if (!isNaN(age)) { f(form, 'age').value = age; }
		if (!isNaN(sa)) { f(form, 'sa').value = sa; }
		if (!isNaN(term) && planById(f(form, 'plan').value).terms.indexOf(term) > -1) { f(form, 'term').value = term; }
		if (MODES[q.get('mode')]) { f(form, 'mode').value = q.get('mode'); }
		if (q.get('income') === 'flexi') { f(form, 'income').value = 'flexi'; }
		if (!isNaN(age) && !isNaN(sa)) { run(false); }
	})();
})();

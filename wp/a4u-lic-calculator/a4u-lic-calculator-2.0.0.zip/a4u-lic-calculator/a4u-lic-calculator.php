<?php
/**
 * Plugin Name: A4U LIC Calculator
 * Plugin URI: https://www.advisor4u.in/lic-calculator/
 * Description: Advanced LIC premium & benefit illustration tool (educational, not an official LIC quotation). Shortcode: [a4u_lic_calculator]
 * Version: 2.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Sahare Financial Services
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'A4U_LIC_VER', '2.0.0' );
define( 'A4U_LIC_OPT', 'a4u_lic_data' );
define( 'A4U_LIC_DB_VER', 6 );
define( 'A4U_LIC_REPO_RAW', 'https://raw.githubusercontent.com/Pankajsahare/sahare-market-hub/main/' );
define( 'A4U_LIC_FILE', __FILE__ );

/* =====================================================================
 * 1. डेटा: plans (LIC sales brochures, 22 Sept 2025 पासूनच्या आवृत्त्या)
 * ===================================================================== */

function a4u_lic_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'a4u_lic_' . $name;
}

// LIC ची सर्वसाधारण mode rebate: yearly 2%, half-yearly 1% (tabular premium वर)
function a4u_lic_std_mode() {
	return array( 'yearly' => -2, 'half' => -1, 'quarter' => 0, 'month' => 0 );
}

// brochure मधून बदलणाऱ्या गोष्टी (upgrade वेळी या keys नव्याने भरल्या जातात)
function a4u_lic_brochure_keys() {
	return array( 'name', 'type', 'min_age', 'max_age', 'min_sa', 'max_maturity', 'min_maturity', 'terms', 'ppt_map', 'ppt_options', 'ppt_max_age_sum',
		'maturity_age', 'survival_pct', 'ga_per_1000', 'tail_age', 'min_age_by_term', 'sa_slabs', 'rebate_slabs', 'rebate_bands', 'mode_adj',
		'death_pct', 'death_sp', 'riders', 'samples', 'sample_sa', 'brochure', 'closed', 'uin' );
}

function a4u_lic_default_plans() {
	$now  = current_time( 'mysql' );
	$base = array( 'active' => 1, 'verified' => 0, 'source' => 'LIC sales brochure sample premiums (estimate)', 'effective' => '2025-09-22',
		'rates' => array(), 'history' => array(), 'updated' => $now, 'rates_updated' => $now, 'closed' => 0, 'bonus_bands' => array(),
		'fab' => 0, 'fab_min_term' => 99, 'srb' => 0, 'mode_adj' => a4u_lic_std_mode(), 'min_age_by_term' => array(), 'min_maturity' => 0 );
	$b    = 'https://licindia.in/documents/20121/';
	$plans = array(
		'714' => array_merge( $base, array(
			'name' => 'New Endowment (714)', 'type' => 'endowment',
			'min_age' => 8, 'max_age' => 50, 'max_maturity' => 75, 'terms' => range( 12, 35 ),
			'min_sa' => 200000, 'sa_slabs' => array( array( 200000, 5000 ), array( 450001, 50000 ), array( 900001, 100000 ) ),
			'rebate_slabs' => array( array( 500000, 2.5 ), array( 1000000, 4 ) ),
			'srb' => 45, 'death_pct' => 100, 'riders' => array( 'adb', 'addb', 'term', 'pwb' ),
			'sample_sa' => 200000, 'samples' => array( array( 20, 15, 14543 ), array( 20, 25, 8369 ), array( 20, 35, 5949 ), array( 30, 15, 14592 ), array( 30, 25, 8497 ), array( 30, 35, 6213 ), array( 40, 15, 14847 ), array( 40, 25, 8987 ), array( 40, 35, 6958 ) ),
			'brochure' => $b . "1319704/LIC%27s+NEW+ENDOWMENT+PLAN+714.pdf/77f3167c-ae64-a1ea-d348-1c66f4455aed",
		) ),
		'715' => array_merge( $base, array(
			'name' => 'New Jeevan Anand (715)', 'type' => 'anand',
			'min_age' => 18, 'max_age' => 50, 'max_maturity' => 75, 'terms' => range( 15, 35 ), 'tail_age' => 100,
			'min_sa' => 200000, 'sa_slabs' => array( array( 200000, 5000 ), array( 450001, 50000 ), array( 900001, 100000 ) ),
			'rebate_slabs' => array( array( 500000, 2.5 ), array( 1000000, 4 ) ),
			'srb' => 45, 'fab' => 100, 'fab_min_term' => 20, 'death_pct' => 125, 'riders' => array( 'adb', 'addb', 'term' ),
			'sample_sa' => 200000, 'samples' => array( array( 20, 15, 16229 ), array( 20, 25, 9339 ), array( 20, 35, 6517 ), array( 30, 15, 16885 ), array( 30, 25, 9810 ), array( 30, 35, 6968 ), array( 40, 15, 18012 ), array( 40, 25, 10711 ), array( 40, 35, 7918 ), array( 50, 15, 19914 ), array( 50, 25, 12397 ) ),
			'brochure' => $b . "1319704/LIC%27s+New+Jeevan+Anand+Sales+Brochure+Eng_141025.pdf/43b60cd9-f6f1-c889-734c-47c565a47ada",
		) ),
		'733' => array_merge( $base, array(
			'name' => 'Jeevan Lakshya (733)', 'type' => 'lakshya',
			'min_age' => 18, 'max_age' => 50, 'min_maturity' => 31, 'max_maturity' => 65, 'terms' => range( 13, 25 ),
			'min_sa' => 200000, 'sa_slabs' => array( array( 200000, 10000 ), array( 400001, 50000 ) ),
			'rebate_slabs' => array( array( 500000, 4 ), array( 1000000, 5 ) ),
			'srb' => 45, 'fab' => 100, 'fab_min_term' => 20, 'death_pct' => 110, 'riders' => array( 'adb', 'addb', 'term' ),
			'sample_sa' => 200000, 'samples' => array( array( 20, 13, 20217 ), array( 20, 15, 16670 ), array( 20, 20, 11711 ), array( 20, 25, 9006 ), array( 30, 13, 20286 ), array( 30, 15, 16758 ), array( 30, 20, 11858 ), array( 30, 25, 9222 ), array( 40, 13, 20678 ), array( 40, 15, 17209 ), array( 40, 20, 12495 ), array( 40, 25, 10074 ), array( 50, 13, 22030 ), array( 50, 15, 18698 ) ),
			'brochure' => $b . "1319704/LIC+Jeevan+Lakshya+Sales+Brochure_Eng_06112025.pdf/fcc745f6-e73e-c825-d3a6-9831221c5cc9",
		) ),
		'736' => array_merge( $base, array(
			'name' => 'Jeevan Labh (736)', 'type' => 'labh',
			'min_age' => 8, 'max_age' => 59, 'max_maturity' => 75, 'ppt_map' => array( 16 => 10, 21 => 15, 25 => 16 ),
			'min_sa' => 200000, 'sa_slabs' => array( array( 200000, 10000 ), array( 450001, 25000 ) ),
			'rebate_slabs' => array( array( 500000, 2 ), array( 1000000, 3 ), array( 1500000, 3.5 ) ),
			'srb' => 49, 'fab' => 200, 'fab_min_term' => 21, 'death_pct' => 100, 'riders' => array( 'adb', 'addb', 'term', 'pwb' ),
			'sample_sa' => 200000, 'samples' => array( array( 20, 16, 17718 ), array( 20, 21, 11623 ), array( 20, 25, 9908 ), array( 30, 16, 17767 ), array( 30, 21, 11701 ), array( 30, 25, 10025 ), array( 40, 16, 18012 ), array( 40, 21, 12054 ), array( 40, 25, 10476 ), array( 50, 16, 18855 ), array( 50, 21, 13083 ), array( 50, 25, 11682 ) ),
			'brochure' => $b . "1319704/LIC_Jeevan+labh_Sales+Brochure_Eng.pdf/cafcd0b7-8f9d-6b65-f5e9-b2aad0788c98",
		) ),
		'745' => array_merge( $base, array(
			'name' => 'Jeevan Umang (745)', 'type' => 'umang',
			'min_age' => 0, 'max_age' => 55, 'max_maturity' => 100, 'ppt_options' => array( 15, 20, 25, 30 ), 'ppt_max_age_sum' => 70, 'maturity_age' => 100, 'survival_pct' => 8,
			'min_sa' => 200000, 'sa_slabs' => array( array( 200000, 25000 ), array( 450001, 50000 ), array( 900001, 100000 ) ),
			'rebate_slabs' => array( array( 500000, 2.5 ), array( 1000000, 3.5 ), array( 2500000, 4 ) ),
			'srb' => 42, 'fab' => 300, 'fab_min_term' => 25, 'death_pct' => 100, 'riders' => array( 'adb', 'addb', 'term', 'pwb' ),
			'sample_sa' => 200000, 'samples' => array( array( 20, 15, 16542 ), array( 20, 20, 11407 ), array( 20, 25, 8536 ), array( 20, 30, 6840 ), array( 30, 15, 16542 ), array( 30, 20, 11407 ), array( 30, 25, 8595 ), array( 30, 30, 7027 ), array( 40, 15, 16542 ), array( 40, 20, 11476 ), array( 40, 25, 9036 ), array( 40, 30, 7664 ), array( 50, 15, 16562 ), array( 50, 20, 12368 ) ),
			'brochure' => $b . "1319704/745+LIC_Jeevan+Umang_Eng+_141025.pdf/d67dc9dc-ca37-7e1e-d662-132423c49d15",
		) ),
		'717' => array_merge( $base, array(
			'name' => 'Single Premium Endowment (717)', 'type' => 'single',
			'min_age' => 0, 'max_age' => 65, 'min_maturity' => 18, 'max_maturity' => 75, 'terms' => range( 10, 25 ),
			'min_sa' => 100000, 'sa_slabs' => array( array( 100000, 10000 ), array( 250001, 25000 ) ),
			'rebate_slabs' => array( array( 200000, 20 ), array( 300000, 30 ), array( 500000, 40 ) ),
			'srb' => 45, 'death_sp' => array( array( 49, 1.25 ), array( 200, 1.10 ) ), 'death_pct' => 100, 'riders' => array( 'addb', 'term' ), 'mode_adj' => array(),
			'sample_sa' => 100000, 'samples' => array( array( 10, 10, 77910 ), array( 10, 15, 66650 ), array( 10, 25, 50005 ), array( 20, 10, 77985 ), array( 20, 15, 66775 ), array( 20, 25, 50255 ), array( 30, 10, 78010 ), array( 30, 15, 66865 ), array( 30, 25, 50695 ), array( 40, 10, 78180 ), array( 40, 15, 67335 ), array( 40, 25, 52340 ), array( 50, 10, 78800 ), array( 50, 15, 68800 ), array( 50, 25, 56160 ), array( 60, 10, 79965 ), array( 60, 15, 71405 ) ),
			'brochure' => $b . "1319704/717+LIC_Single+Premium+Endowment+plan_Eng_141025.pdf/7215c5ff-2071-669a-1a4e-71182e2a102e",
		) ),
		'771' => array_merge( $base, array(
			'name' => 'Jeevan Utsav (771)', 'type' => 'utsav',
			'min_age' => 0, 'max_age' => 65, 'max_maturity' => 100, 'ppt_options' => range( 5, 16 ), 'ppt_max_age_sum' => 75, 'maturity_age' => 100, 'survival_pct' => 10, 'ga_per_1000' => 40,
			'min_age_by_term' => array( 5 => 8, 6 => 8, 7 => 8, 8 => 8, 9 => 7, 10 => 6, 11 => 5, 12 => 4, 13 => 3, 14 => 2, 15 => 1, 16 => 0 ),
			'min_sa' => 500000, 'sa_slabs' => array( array( 500000, 25000 ), array( 2400001, 100000 ) ),
			'rebate_slabs' => array(), // brochure मध्ये टक्के दिलेले नाहीत — admin मध्ये भरा
			'mode_adj' => array( 'yearly' => 0, 'half' => 1.75, 'quarter' => 2.5, 'month' => 3.25 ), // Utsav मध्ये rebate नाही, loading आहे
			'death_pct' => 100, 'riders' => array( 'adb', 'addb', 'term', 'pwb' ),
			'sample_sa' => 500000, 'samples' => array( array( 10, 5, 109575 ), array( 10, 8, 72600 ), array( 10, 12, 44250 ), array( 10, 16, 29900 ), array( 30, 5, 110150 ), array( 30, 8, 72600 ), array( 30, 12, 44275 ), array( 30, 16, 30025 ), array( 50, 5, 118625 ), array( 50, 8, 72600 ), array( 50, 12, 45225 ), array( 50, 16, 33475 ) ),
			'brochure' => $b . "1319704/Jeevan+Utsav+Sales+Brochure_141025.pdf/da84d78a-ef72-c80f-b8df-83bb7565f087",
		) ),
		'883' => array_merge( $base, array(
			'name' => 'Jeevan Utsav Single Premium (883)', 'type' => 'utsav_sp',
			'min_age' => 0, 'max_age' => 65, 'max_maturity' => 100, 'ppt_options' => range( 7, 17 ), 'maturity_age' => 100, 'survival_pct' => 10, 'ga_per_1000' => 40,
			'min_age_by_term' => array( 7 => 10, 8 => 9, 9 => 8, 10 => 7, 11 => 6, 12 => 5, 13 => 4, 14 => 3, 15 => 2, 16 => 1, 17 => 0 ),
			'min_sa' => 500000, 'sa_slabs' => array( array( 500000, 25000 ), array( 2450001, 50000 ) ),
			'rebate_bands' => array(
				array( 20, array( array( 1000000, 11 ), array( 2500000, 19 ), array( 5000000, 21 ) ) ),
				array( 40, array( array( 1000000, 9 ), array( 2500000, 15 ), array( 5000000, 18 ) ) ),
				array( 55, array( array( 1000000, 6.5 ), array( 2500000, 12 ), array( 5000000, 13 ) ) ),
				array( 65, array( array( 1000000, 5 ), array( 2500000, 9 ), array( 5000000, 10 ) ) ),
			),
			'death_sp' => array( array( 200, 1.25 ) ), 'death_pct' => 100, 'riders' => array(), 'mode_adj' => array(),
			'sample_sa' => 500000, 'samples' => array( array( 10, 8, 464150 ), array( 10, 12, 361875 ), array( 10, 16, 285725 ), array( 30, 8, 464150 ), array( 30, 12, 361875 ), array( 30, 16, 286725 ), array( 50, 8, 464150 ), array( 50, 12, 361875 ), array( 50, 16, 300800 ) ),
			'brochure' => $b . "1639835/LIC_Jeevan+Utsav++Single+Premium_Sales+Brochure_English.pdf/4f48bd54-fab2-1b97-cc38-fb19dc663399",
		) ),
	);
	// ---- बंद plans (1 Oct 2024 पासून withdraw; जुन्या policyholders साठी, default बंद) ----
	$closed = array(
		'914' => array( 'New Endowment (914)', 'endowment', 8, 55, 100000, 70, array( 'terms' => range( 12, 35 ), 'srb' => 45, 'death_pct' => 100 ) ),
		'915' => array( 'New Jeevan Anand (915)', 'anand', 18, 50, 100000, 75, array( 'terms' => range( 15, 35 ), 'srb' => 45, 'fab' => 100, 'fab_min_term' => 20, 'tail_age' => 100, 'death_pct' => 125 ) ),
		'936' => array( 'Jeevan Labh (936)', 'labh', 8, 59, 100000, 75, array( 'ppt_map' => array( 16 => 10, 21 => 15, 25 => 16 ), 'srb' => 49, 'fab' => 200, 'fab_min_term' => 21, 'death_pct' => 100 ) ),
		'945' => array( 'Jeevan Umang (945)', 'umang', 1, 55, 200000, 100, array( 'ppt_options' => array( 15, 20, 25, 30 ), 'ppt_max_age_sum' => 70, 'maturity_age' => 100, 'survival_pct' => 8, 'srb' => 42, 'fab' => 300, 'fab_min_term' => 25, 'death_pct' => 100 ) ),
	);
	$uins = array( '714' => '512N277V03', '715' => '512N279V03', '733' => '512N297V03', '736' => '512N304V03', '745' => '512N312V03', '717' => '512N283V03', '771' => '512N363V02', '883' => '' );
	foreach ( $uins as $id => $u ) { $plans[ $id ]['uin'] = $u; }
	foreach ( $closed as $id => $c ) {
		$plans[ $id ] = array_merge( $base, array(
			'name' => $c[0] . ' - Closed', 'type' => $c[1], 'min_age' => $c[2], 'max_age' => $c[3], 'min_sa' => $c[4], 'max_maturity' => $c[5],
			'sa_slabs' => array( array( $c[4], 5000 ) ), 'rebate_slabs' => array( array( 200000, 2 ) ), 'riders' => array( 'adb' ),
			'active' => 0, 'closed' => 1, 'uin' => '', 'source' => 'Demo formula - closed plan', 'effective' => '', 'samples' => array(), 'sample_sa' => 0, 'brochure' => '',
		), $c[6] );
	}
	return $plans;
}

function a4u_lic_defaults() {
	return array(
		'rate_version' => 1,
		'updated'      => current_time( 'mysql' ),
		'settings'     => array(
			'gst'            => 0, // 22 Sept 2025 पासून individual life premium GST-free
			'modal'          => array( 'yearly' => 1, 'half' => 0.51, 'quarter' => 0.26, 'month' => 0.087 ), // फक्त mode_adj नसलेल्या plans साठी
			'rider_per_1000' => 0.5,
			'rider_addb'     => 1,
			'rider_term'     => 1.5,
			'rider_pwb_pct'  => 2,
			'rider_csv'      => '', // S1: rider,age,term,rate_per_1000
			'whatsapp'       => '919405908605',
			'links'          => "Home|https://www.advisor4u.in/\nWhatsApp|https://wa.me/919405908605",
			'retention_days' => 180,
			'faq'            => 1,
			'base_slug'      => 'lic-calculator', // S7: /lic-calculator/714/
			// v2.0 — PDF branding (IRDAI जाहिरात नियमांसाठी agent ची माहिती)
			'brand_name'     => 'Sahare Financial Services',
			'agent_name'     => 'Pankaj Digambar Sahare',
			'agent_type'     => 'Insurance Agent, Life Insurance Corporation of India',
			'agency_code'    => 'LIC0286499F',
			'agency_branch'  => '99F',
			'brand_phone'    => '9405908605',
			'brand_email'    => 'info@advisor4u.in',
			'brand_web'      => 'www.advisor4u.in',
			'logo_url'       => '', // रिकामं = plugin मधला logo
			'color_gold'     => '#B8924A',
			'color_green'    => '#3F5A22',
			'sync_url'       => A4U_LIC_REPO_RAW . 'data/lic/lic-plans.json',
			'update_url'     => A4U_LIC_REPO_RAW . 'wp/a4u-lic-calculator/update.json',
		),
		'plans'        => a4u_lic_default_plans(),
	);
}

/* ---------- छोटे helpers: text ⇄ array (admin साठी) ---------- */

// "200000:5000, 450001:50000" ⇄ [[200000,5000],[450001,50000]] (2 किंवा 3 भाग)
function a4u_lic_pairs_to_text( $rows ) {
	return implode( ', ', array_map( function ( $r ) { return implode( ':', array_map( function ( $v ) { return 0 + $v; }, (array) $r ) ); }, (array) $rows ) );
}
function a4u_lic_text_to_pairs( $text, $parts = 2 ) {
	$out = array();
	foreach ( preg_split( '/[,\n]+/', (string) $text ) as $chunk ) {
		$bits = array_map( 'trim', explode( ':', $chunk ) );
		if ( count( $bits ) !== $parts ) { continue; }
		$ok = true;
		foreach ( $bits as $v ) { if ( ! is_numeric( $v ) ) { $ok = false; } }
		if ( $ok ) { $out[] = array_map( function ( $v ) { return 0 + $v; }, $bits ); }
	}
	usort( $out, function ( $a, $b ) { return $a[0] <=> $b[0]; } );
	return $out;
}
// जुना नाव ठेवला (v1.3 compatibility)
function a4u_lic_slabs_to_text( $s ) { return a4u_lic_pairs_to_text( $s ); }
function a4u_lic_text_to_slabs( $t ) { return array_values( array_filter( a4u_lic_text_to_pairs( $t ), function ( $r ) { return $r[1] > 0; } ) ); }

function a4u_lic_mode_to_text( $m ) {
	$out = array();
	foreach ( array( 'yearly', 'half', 'quarter', 'month' ) as $k ) { if ( isset( $m[ $k ] ) ) { $out[] = $k . ':' . ( 0 + $m[ $k ] ); } }
	return implode( ', ', $out );
}
function a4u_lic_text_to_mode( $text ) {
	$out = array();
	foreach ( preg_split( '/[,\n]+/', (string) $text ) as $chunk ) {
		if ( preg_match( '/^\s*(yearly|half|quarter|month)\s*:\s*(-?[\d.]+)\s*$/', $chunk, $m ) ) { $out[ $m[1] ] = max( -20, min( 20, (float) $m[2] ) ); }
	}
	return $out;
}

function a4u_lic_samples_to_text( $s ) {
	return implode( "\n", array_map( function ( $r ) { return implode( ',', $r ); }, (array) $s ) );
}
function a4u_lic_text_to_samples( $text ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		$c = array_map( 'trim', explode( ',', $line ) );
		if ( 3 === count( $c ) && is_numeric( $c[0] ) && is_numeric( $c[1] ) && is_numeric( $c[2] ) && (float) $c[2] > 0 ) { $out[] = array( (int) $c[0], (int) $c[1], (float) $c[2] ); }
	}
	return $out;
}

/* ---------- get / save ---------- */

function a4u_lic_data() {
	$d = get_option( A4U_LIC_OPT );
	if ( ! is_array( $d ) ) {
		$d = a4u_lic_defaults();
		add_option( A4U_LIC_OPT, $d, '', false );
	}
	return $d;
}

function a4u_lic_save( $d, $bump = true ) {
	if ( $bump ) { $d['rate_version'] = (int) ( $d['rate_version'] ?? 0 ) + 1; }
	$d['updated'] = current_time( 'mysql' );
	update_option( A4U_LIC_OPT, $d, false );
	do_action( 'litespeed_purge_all' ); // LiteSpeed cache साफ
}

function a4u_lic_rates_to_map( $rates ) {
	$m = array();
	foreach ( (array) $rates as $k => $r ) {
		if ( is_array( $r ) && count( $r ) >= 3 ) {
			$m[ (int) $r[0] . '|' . (int) $r[1] ] = (float) $r[2];
		} elseif ( is_numeric( $r ) && is_string( $k ) && false !== strpos( $k, '|' ) ) {
			$m[ $k ] = (float) $r;
		}
	}
	return $m;
}

// plan चे term / PPT / GA period पर्याय
function a4u_lic_plan_terms( $p ) {
	switch ( $p['type'] ) {
		case 'labh':
			return array_map( 'intval', array_keys( (array) ( $p['ppt_map'] ?? array() ) ) );
		case 'umang':
		case 'utsav':
		case 'utsav_sp':
			return array_map( 'intval', (array) ( $p['ppt_options'] ?? array() ) );
		default:
			return array_map( 'intval', (array) ( $p['terms'] ?? array() ) );
	}
}

function a4u_lic_stat_add( $event, $n = 1 ) {
	global $wpdb;
	$t = a4u_lic_table( 'stats' );
	$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (event, hits) VALUES (%s, %d) ON DUPLICATE KEY UPDATE hits = hits + %d", $event, $n, $n ) ); // phpcs:ignore
}

// S1: rider CSV "adb,30,20,0.55" → ['adb|30|20' => 0.55]
function a4u_lic_rider_map( $csv ) {
	$m = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $csv ) as $line ) {
		$c = array_map( 'trim', explode( ',', $line ) );
		if ( 4 === count( $c ) && in_array( $c[0], array( 'adb', 'addb', 'term', 'pwb' ), true ) && is_numeric( $c[1] ) && is_numeric( $c[2] ) && is_numeric( $c[3] ) ) {
			$m[ $c[0] . '|' . (int) $c[1] . '|' . (int) $c[2] ] = (float) $c[3];
		}
	}
	return $m;
}

/* =====================================================================
 * 2. Install / Upgrade + Cron + Rewrite (S7)
 * ===================================================================== */

function a4u_lic_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$c = $wpdb->get_charset_collate();
	dbDelta( 'CREATE TABLE ' . a4u_lic_table( 'leads' ) . " (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		created datetime NOT NULL,
		name varchar(100) NOT NULL,
		mobile varchar(15) NOT NULL,
		plan varchar(100) NOT NULL DEFAULT '',
		sa bigint(20) unsigned NOT NULL DEFAULT 0,
		premium decimal(12,2) NOT NULL DEFAULT 0,
		PRIMARY KEY  (id),
		KEY created (created)
	) {$c};" );
	dbDelta( 'CREATE TABLE ' . a4u_lic_table( 'stats' ) . " (
		event varchar(20) NOT NULL,
		hits bigint(20) unsigned NOT NULL DEFAULT 0,
		PRIMARY KEY  (event)
	) {$c};" );

	$old_ver = (int) get_option( 'a4u_lic_db_ver', 0 );
	$d       = get_option( A4U_LIC_OPT );
	if ( is_array( $d ) ) {
		$def = a4u_lic_defaults();
		if ( ! isset( $d['rate_version'] ) ) { $d['rate_version'] = (int) ( $d['version'] ?? 1 ); }
		unset( $d['version'] );
		$d['settings']          = ( is_array( $d['settings'] ?? null ) ? $d['settings'] : array() ) + $def['settings'];
		$d['settings']['modal'] = (array) $d['settings']['modal'] + $def['settings']['modal'];
		foreach ( $def['plans'] as $id => $dp ) {
			if ( ! isset( $d['plans'][ $id ] ) ) { $d['plans'][ $id ] = $dp; continue; }
			$d['plans'][ $id ] = (array) $d['plans'][ $id ] + $dp;
			// v1.4: brochure मधले अधिकृत नियम नव्याने भर (rates, verified, source, bonus तसेच राहतात)
			if ( $old_ver < 5 ) {
				foreach ( a4u_lic_brochure_keys() as $k ) {
					if ( 'name' === $k && ! empty( $d['plans'][ $id ]['closed'] ) ) { continue; }
					if ( array_key_exists( $k, $dp ) ) { $d['plans'][ $id ][ $k ] = $dp[ $k ]; }
				}
				if ( ! empty( $dp['closed'] ) ) { $d['plans'][ $id ]['active'] = 0; }
			}
		}
		foreach ( $d['plans'] as $id => $p ) {
			$d['plans'][ $id ]['rates'] = a4u_lic_rates_to_map( $p['rates'] ?? array() );
			foreach ( (array) ( $p['history'] ?? array() ) as $i => $h ) {
				$d['plans'][ $id ]['history'][ $i ]['rates'] = a4u_lic_rates_to_map( $h['rates'] ?? array() );
			}
		}
		foreach ( (array) ( $d['leads'] ?? array() ) as $l ) {
			$wpdb->insert( a4u_lic_table( 'leads' ), array(
				'created' => $l['date'] ?? current_time( 'mysql' ),
				'name'    => (string) ( $l['name'] ?? '' ),
				'mobile'  => (string) ( $l['mobile'] ?? '' ),
				'plan'    => (string) ( $l['plan'] ?? '' ),
				'sa'      => absint( $l['sa'] ?? 0 ),
				'premium' => (float) ( $l['premium'] ?? 0 ),
			) );
		}
		foreach ( (array) ( $d['stats'] ?? array() ) as $k => $v ) {
			if ( (int) $v > 0 ) { a4u_lic_stat_add( sanitize_key( $k ), (int) $v ); }
		}
		unset( $d['leads'], $d['stats'] );
		$d['rate_version'] = (int) $d['rate_version'] + 1;
		update_option( A4U_LIC_OPT, $d, false );
	} else {
		add_option( A4U_LIC_OPT, a4u_lic_defaults(), '', false );
	}

	if ( ! wp_next_scheduled( 'a4u_lic_purge' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'a4u_lic_purge' );
	}
	if ( ! wp_next_scheduled( 'a4u_lic_sync' ) ) {
		wp_schedule_event( time() + 300, 'daily', 'a4u_lic_sync' );
	}
	update_option( 'a4u_lic_flush', 1, false ); // पुढच्या init ला rewrite rules refresh
	update_option( 'a4u_lic_db_ver', A4U_LIC_DB_VER, false );
}
register_activation_hook( __FILE__, 'a4u_lic_install' );

add_action( 'plugins_loaded', function () {
	if ( (int) get_option( 'a4u_lic_db_ver', 0 ) < A4U_LIC_DB_VER ) { a4u_lic_install(); }
} );

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'a4u_lic_purge' );
	wp_clear_scheduled_hook( 'a4u_lic_sync' );
	flush_rewrite_rules();
} );

add_action( 'a4u_lic_purge', function () {
	global $wpdb;
	$d    = a4u_lic_data();
	$days = max( 30, (int) ( $d['settings']['retention_days'] ?? 180 ) );
	$cut  = wp_date( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
	$t    = a4u_lic_table( 'leads' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE created < %s", $cut ) ); // phpcs:ignore
} );

// S7: /lic-calculator/714/ → त्याच page वर plan 714 आधीच निवडलेला
function a4u_lic_base_slug() {
	$d = a4u_lic_data();
	return trim( (string) ( $d['settings']['base_slug'] ?? 'lic-calculator' ), '/' );
}
add_action( 'init', function () {
	$slug = a4u_lic_base_slug();
	if ( '' !== $slug ) {
		add_rewrite_rule( '^' . preg_quote( $slug, '#' ) . '/([0-9]{3})/?$', 'index.php?pagename=' . $slug . '&a4u_plan=$matches[1]', 'top' );
	}
	if ( get_option( 'a4u_lic_flush' ) ) {
		flush_rewrite_rules( false );
		delete_option( 'a4u_lic_flush' );
	}
} );
add_filter( 'query_vars', function ( $v ) { $v[] = 'a4u_plan'; return $v; } );

function a4u_lic_current_plan() {
	$id = sanitize_key( (string) get_query_var( 'a4u_plan' ) );
	if ( '' === $id ) { return null; }
	$d = a4u_lic_data();
	return ( ! empty( $d['plans'][ $id ]['active'] ) ) ? array( $id, $d['plans'][ $id ] ) : null;
}
// plan page चं title + canonical (WordPress + Rank Math)
function a4u_lic_plan_title( $title ) {
	$cp = a4u_lic_current_plan();
	return $cp ? 'LIC ' . $cp[1]['name'] . ' Premium Calculator | Advisor4u' : $title;
}
add_filter( 'pre_get_document_title', function ( $t ) { return a4u_lic_current_plan() ? a4u_lic_plan_title( $t ) : $t; }, 20 );
add_filter( 'rank_math/frontend/title', 'a4u_lic_plan_title' );
add_filter( 'rank_math/frontend/canonical', function ( $url ) {
	$cp = a4u_lic_current_plan();
	return $cp ? home_url( '/' . a4u_lic_base_slug() . '/' . $cp[0] . '/' ) : $url;
} );
add_filter( 'rank_math/frontend/description', function ( $desc ) {
	$cp = a4u_lic_current_plan();
	return $cp ? 'Calculate premium, maturity and year-wise benefits for LIC ' . $cp[1]['name'] . '. Free educational illustration based on LIC brochure figures.' : $desc;
} );

/* =====================================================================
 * 3. Admin: flash + menu + notice
 * ===================================================================== */

function a4u_lic_flash( $ok = '', $errors = array() ) {
	set_transient( 'a4u_lic_flash_' . get_current_user_id(), array( 'ok' => $ok, 'err' => $errors ), 120 );
}
function a4u_lic_flash_take() {
	$k = 'a4u_lic_flash_' . get_current_user_id();
	$f = get_transient( $k );
	if ( $f ) { delete_transient( $k ); }
	return is_array( $f ) ? $f : array( 'ok' => '', 'err' => array() );
}

add_action( 'admin_menu', function () {
	add_menu_page( 'A4U LIC Calculator', 'A4U LIC', 'manage_options', 'a4u-lic', 'a4u_lic_admin_page', 'dashicons-calculator', 26 );
} );

add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'toplevel_page_a4u-lic' ), true ) ) { return; }
	$d    = a4u_lic_data();
	$warn = array();
	foreach ( $d['plans'] as $p ) {
		if ( empty( $p['active'] ) ) { continue; }
		$stale = ( time() - strtotime( $p['rates_updated'] ?? $p['updated'] ) ) > 90 * DAY_IN_SECONDS;
		if ( empty( $p['verified'] ) || empty( $p['rates'] ) || $stale ) { $warn[] = $p['name']; }
	}
	if ( get_option( 'a4u_lic_pending' ) ) {
		echo '<div class="notice notice-info"><p><strong>A4U LIC:</strong> New LIC brochure data is waiting for your approval. <a href="' . esc_url( admin_url( 'admin.php?page=a4u-lic&tab=sync' ) ) . '">Review changes</a></p></div>';
	}
	if ( $warn ) {
		echo '<div class="notice notice-warning"><p><strong>A4U LIC:</strong> Showing brochure-based estimates (no verified CSV) for: ' . esc_html( implode( ', ', $warn ) ) . '. <a href="' . esc_url( admin_url( 'admin.php?page=a4u-lic' ) ) . '">Open Rates panel</a></p></div>';
	}
} );

/* ---------- S4: Quick check — brochure sample vs आपले CSV rates ---------- */

function a4u_lic_quick_check( $p ) {
	$rows = array();
	if ( empty( $p['samples'] ) || empty( $p['sample_sa'] ) ) { return $rows; }
	$single = in_array( $p['type'], array( 'single', 'utsav_sp' ), true );
	$adj    = $single ? 0 : (float) ( $p['mode_adj']['yearly'] ?? 0 );
	foreach ( $p['samples'] as $s ) {
		$key  = (int) $s[0] . '|' . (int) $s[1];
		$rate = $p['rates'][ $key ] ?? null;
		$ours = null === $rate ? null : $rate * $p['sample_sa'] / 1000 * ( 1 + $adj / 100 );
		$diff = null === $ours ? null : ( $ours - $s[2] ) / $s[2] * 100;
		$rows[] = array( $s[0], $s[1], $s[2], $ours, $diff );
	}
	return $rows;
}

/* =====================================================================
 * 4. Admin: page render
 * ===================================================================== */

function a4u_lic_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	global $wpdb;
	$d     = a4u_lic_data();
	$tab   = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'plans'; // phpcs:ignore
	$base  = admin_url( 'admin.php?page=a4u-lic' );
	$flash = a4u_lic_flash_take();
	$lt    = a4u_lic_table( 'leads' );
	$st    = a4u_lic_table( 'stats' );
	$lead_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$lt}" ); // phpcs:ignore
	$in    = 'style="width:100%"';
	?>
	<div class="wrap">
		<h1>A4U LIC Calculator <span style="font-size:13px;color:#666;">Rate v<?php echo (int) $d['rate_version']; ?> &bull; <?php echo esc_html( $d['updated'] ); ?></span></h1>
		<?php if ( $flash['ok'] ) : ?><div class="notice notice-success is-dismissible"><p>Saved: <?php echo esc_html( $flash['ok'] ); ?></p></div><?php endif; ?>
		<h2 class="nav-tab-wrapper">
			<a class="nav-tab <?php echo 'plans' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $base . '&tab=plans' ); ?>">Plans &amp; Rates</a>
			<a class="nav-tab <?php echo 'leads' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $base . '&tab=leads' ); ?>">Leads (<?php echo (int) $lead_count; ?>)</a>
			<a class="nav-tab <?php echo 'stats' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $base . '&tab=stats' ); ?>">Stats</a>
			<a class="nav-tab <?php echo 'sync' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $base . '&tab=sync' ); ?>">Data sync<?php echo get_option( 'a4u_lic_pending' ) ? ' <span class="update-plugins count-1"><span class="plugin-count">1</span></span>' : ''; ?></a>
			<a class="nav-tab <?php echo 'settings' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $base . '&tab=settings' ); ?>">Settings</a>
		</h2>

		<?php if ( 'plans' === $tab ) : ?>
			<p style="max-width:860px;">Three levels of accuracy: <strong>1) Verified CSV</strong> (exact, from LIC tariff) &rarr; <strong>2) Brochure estimate</strong> (interpolated from the sample premiums printed in the official LIC sales brochure) &rarr; <strong>3) Demo</strong>. CSV format: <code>age,term,rate_per_1000</code> &mdash; for Umang/Utsav the term column means PPT, for Utsav Single Premium it means GA period. Rates are the <em>tabular annual</em> premium per Rs.1000 BSA (before mode/HSA rebate).</p>
			<?php foreach ( $d['plans'] as $id => $p ) : $qc = a4u_lic_quick_check( $p ); ?>
			<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;margin:14px 0;max-width:960px;">
				<h3 style="margin-top:0;"><?php echo esc_html( $p['name'] ); ?>
					<?php echo ! empty( $p['closed'] ) ? '<span style="background:#eee;padding:1px 6px;border-radius:4px;font-size:11px;">CLOSED PLAN</span>' : ''; ?>
					<?php echo ! empty( $p['verified'] ) ? '<span style="color:#00701a;font-size:12px;">&#9679; Verified CSV</span>' : ( ! empty( $p['samples'] ) ? '<span style="color:#996800;font-size:12px;">&#9679; Brochure estimate</span>' : '<span style="color:#b32d2e;font-size:12px;">&#9679; Demo</span>' ); ?>
					<span style="font-size:12px;color:#666;">CSV rows: <?php echo count( $p['rates'] ); ?> | rates updated: <?php echo esc_html( $p['rates_updated'] ?? $p['updated'] ); ?></span>
				</h3>
				<?php if ( ! empty( $p['brochure'] ) ) : ?><p style="margin-top:-6px;"><a href="<?php echo esc_url( $p['brochure'] ); ?>" target="_blank" rel="noopener">Official LIC sales brochure (PDF)</a></p><?php endif; ?>
				<?php if ( ! empty( $flash['err'][ $id ] ) ) : ?><div class="notice notice-error inline"><p><?php echo esc_html( $flash['err'][ $id ] ); ?></p></div><?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="a4u_lic_save_plan">
					<input type="hidden" name="plan" value="<?php echo esc_attr( $id ); ?>">
					<?php wp_nonce_field( 'a4u_lic_save_plan', 'a4u_nonce' ); ?>
					<table class="form-table" role="presentation"><tbody>
						<tr><th>Active</th><td><label><input type="checkbox" name="active" value="1" <?php checked( $p['active'], 1 ); ?>> Show in calculator</label></td></tr>
						<tr><th>Entry age (min / max)</th><td><input type="number" min="0" max="99" name="min_age" value="<?php echo (int) $p['min_age']; ?>" style="width:80px"> / <input type="number" min="0" max="99" name="max_age" value="<?php echo (int) $p['max_age']; ?>" style="width:80px"></td></tr>
						<tr><th>Min Sum Assured / Max maturity age</th><td><input type="number" min="1000" name="min_sa" value="<?php echo (int) $p['min_sa']; ?>" style="width:120px"> / <input type="number" min="18" max="100" name="max_maturity" value="<?php echo (int) $p['max_maturity']; ?>" style="width:80px"></td></tr>
						<tr><th>Allowed term / PPT</th><td><code><?php echo esc_html( implode( ', ', a4u_lic_plan_terms( $p ) ) ); ?></code></td></tr>
						<tr><th>SA multiples <small>(from SA : multiple)</small></th><td><input type="text" name="sa_slabs" value="<?php echo esc_attr( a4u_lic_pairs_to_text( $p['sa_slabs'] ?? array() ) ); ?>" <?php echo $in; // phpcs:ignore ?>></td></tr>
						<?php if ( empty( $p['rebate_bands'] ) ) : ?>
						<tr><th>HSA rebate <small>(from SA : Rs. per 1000 BSA)</small></th><td><input type="text" name="rebate_slabs" value="<?php echo esc_attr( a4u_lic_pairs_to_text( $p['rebate_slabs'] ?? array() ) ); ?>" <?php echo $in; // phpcs:ignore ?> placeholder="500000:2.5, 1000000:4"></td></tr>
						<?php else : ?>
						<tr><th>HSA rebate</th><td><span style="color:#666;">Age-band table from brochure (fixed in code).</span></td></tr>
						<?php endif; ?>
						<?php if ( ! in_array( $p['type'], array( 'single', 'utsav_sp' ), true ) ) : ?>
						<tr><th>Mode rebate(−) / loading(+) %</th><td><input type="text" name="mode_adj" value="<?php echo esc_attr( a4u_lic_mode_to_text( $p['mode_adj'] ?? array() ) ); ?>" <?php echo $in; // phpcs:ignore ?> placeholder="yearly:-2, half:-1, quarter:0, month:0"></td></tr>
						<?php endif; ?>
						<tr><th>Bonus: SRB / FAB (Rs. per 1000) / FAB min term</th><td><input type="number" min="0" step="0.01" name="srb" value="<?php echo esc_attr( $p['srb'] ); ?>" style="width:80px"> / <input type="number" min="0" step="0.01" name="fab" value="<?php echo esc_attr( $p['fab'] ); ?>" style="width:80px"> / <input type="number" min="0" name="fab_min_term" value="<?php echo (int) $p['fab_min_term']; ?>" style="width:80px"> <span style="color:#666;">(non-guaranteed; latest LIC bonus circular)</span></td></tr>
						<tr><th>Bonus by term band <small>(from term : SRB : FAB)</small></th><td><input type="text" name="bonus_bands" value="<?php echo esc_attr( a4u_lic_pairs_to_text( $p['bonus_bands'] ?? array() ) ); ?>" <?php echo $in; // phpcs:ignore ?> placeholder="12:40:0, 21:45:50, 26:47:100"><p style="color:#666;margin:2px 0 0;">Optional. If filled, overrides the single SRB/FAB above for that term range.</p></td></tr>
						<tr><th>Death SA (% of BSA)</th><td><input type="number" min="0" max="500" name="death_pct" value="<?php echo (int) ( $p['death_pct'] ?? 0 ); ?>" style="width:80px"> <span style="color:#666;">Regular premium: higher of this % of BSA and 7 &times; annualised premium (0 = hide)</span></td></tr>
						<tr><th>Riders allowed</th><td><?php foreach ( array( 'adb' => 'Accident Benefit', 'addb' => 'AD&amp;DB', 'term' => 'Term rider', 'pwb' => 'Premium Waiver (PWB)' ) as $rk => $rl ) : ?><label style="margin-right:12px;"><input type="checkbox" name="riders[]" value="<?php echo esc_attr( $rk ); ?>" <?php checked( in_array( $rk, (array) ( $p['riders'] ?? array() ), true ) ); ?>> <?php echo $rl; // phpcs:ignore ?></label><?php endforeach; ?></td></tr>
						<tr><th>Brochure sample premiums</th><td>Sample BSA <input type="number" min="0" name="sample_sa" value="<?php echo (int) ( $p['sample_sa'] ?? 0 ); ?>" style="width:110px"><textarea name="samples" rows="3" style="width:100%;font-family:monospace;margin-top:4px;" placeholder="age,term,premium"><?php echo esc_textarea( a4u_lic_samples_to_text( $p['samples'] ?? array() ) ); ?></textarea><p style="color:#666;margin:2px 0 0;">Yearly-mode premium for the sample BSA, exactly as printed in the brochure.</p></td></tr>
						<tr><th>Source (document reference)</th><td><input type="text" name="source" value="<?php echo esc_attr( $p['source'] ); ?>" <?php echo $in; // phpcs:ignore ?>></td></tr>
						<tr><th>Effective date</th><td><input type="date" name="effective" value="<?php echo esc_attr( $p['effective'] ); ?>"></td></tr>
						<tr><th>Verified</th><td><label><input type="checkbox" name="verified" value="1" <?php checked( $p['verified'], 1 ); ?>> I have cross-checked the CSV rates with the official LIC tariff</label></td></tr>
						<tr><th>Import rates CSV</th><td><textarea name="csv" rows="5" style="width:100%;font-family:monospace;" placeholder="30,20,74.45&#10;31,20,74.80&#10;..."></textarea><p style="color:#666;">Leave empty to keep current rates. Invalid / duplicate / out-of-range rows block the import and are listed.</p></td></tr>
					</tbody></table>
					<?php submit_button( 'Save plan', 'primary', 'submit', false ); ?>
				</form>
				<?php if ( $qc ) : ?>
					<details style="margin-top:10px;"><summary><strong>Quick check:</strong> brochure sample vs your CSV</summary>
					<table class="widefat striped" style="max-width:620px;margin-top:6px;"><thead><tr><th>Age</th><th>Term/PPT</th><th>Brochure</th><th>Your CSV</th><th>Diff</th></tr></thead><tbody>
					<?php foreach ( $qc as $r ) : $bad = null !== $r[4] && abs( $r[4] ) > 1; ?>
						<tr><td><?php echo (int) $r[0]; ?></td><td><?php echo (int) $r[1]; ?></td><td><?php echo esc_html( number_format_i18n( $r[2] ) ); ?></td><td><?php echo null === $r[3] ? '&mdash;' : esc_html( number_format_i18n( $r[3] ) ); ?></td><td style="<?php echo $bad ? 'color:#b32d2e;font-weight:600;' : ''; ?>"><?php echo null === $r[4] ? 'no CSV row' : esc_html( sprintf( '%+.2f%%', $r[4] ) ); ?></td></tr>
					<?php endforeach; ?>
					</tbody></table><p style="color:#666;">More than &plusmn;1% (red) usually means a wrong CSV row or wrong mode rebate.</p></details>
				<?php endif; ?>
				<?php if ( ! empty( $p['history'] ) ) : ?>
					<p><strong>Version history:</strong>
					<?php foreach ( $p['history'] as $i => $h ) : ?>
						<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=a4u_lic_restore&plan=' . $id . '&idx=' . $i ), 'a4u_lic_restore' ) ); ?>">Restore v<?php echo (int) $h['version']; ?> (<?php echo esc_html( $h['updated'] ); ?>, <?php echo count( (array) $h['rates'] ); ?> rows)</a>
					<?php endforeach; ?></p>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>

		<?php elseif ( 'leads' === $tab ) :
			$leads = $wpdb->get_results( "SELECT * FROM {$lt} ORDER BY id DESC LIMIT 500", ARRAY_A ); // phpcs:ignore
			?>
			<p>Opt-in leads only (consent required). Auto-deleted after <?php echo (int) $d['settings']['retention_days']; ?> days. <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=a4u_lic_export_leads' ), 'a4u_lic_export' ) ); ?>">Export CSV</a></p>
			<table class="widefat striped" style="max-width:1000px;"><thead><tr><th>Date</th><th>Name</th><th>Mobile</th><th>Plan</th><th>SA</th><th>Premium</th><th></th></tr></thead><tbody>
			<?php if ( empty( $leads ) ) : ?><tr><td colspan="7">No leads yet.</td></tr><?php endif; ?>
			<?php foreach ( $leads as $l ) : ?>
				<tr><td><?php echo esc_html( $l['created'] ); ?></td><td><?php echo esc_html( $l['name'] ); ?></td><td><a href="<?php echo esc_url( 'https://wa.me/91' . $l['mobile'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $l['mobile'] ); ?></a></td><td><?php echo esc_html( $l['plan'] ); ?></td><td><?php echo esc_html( number_format_i18n( (float) $l['sa'] ) ); ?></td><td><?php echo esc_html( number_format_i18n( (float) $l['premium'] ) ); ?></td>
				<td><a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=a4u_lic_del_lead&id=' . (int) $l['id'] ), 'a4u_lic_del_lead' ) ); ?>" onclick="return confirm('Delete this lead?');">Delete</a></td></tr>
			<?php endforeach; ?></tbody></table>

		<?php elseif ( 'stats' === $tab ) :
			$stats = array( 'calculate' => 0, 'compare' => 0, 'pdf' => 0, 'whatsapp' => 0, 'lead' => 0 );
			foreach ( (array) $wpdb->get_results( "SELECT event, hits FROM {$st}", ARRAY_A ) as $r ) { $stats[ $r['event'] ] = (int) $r['hits']; } // phpcs:ignore
			?>
			<table class="widefat striped" style="max-width:500px;"><tbody>
			<?php foreach ( $stats as $k => $v ) : ?><tr><td><?php echo esc_html( ucfirst( $k ) ); ?></td><td><strong><?php echo (int) $v; ?></strong></td></tr><?php endforeach; ?>
			</tbody></table>
			<p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=a4u_lic_reset_stats' ), 'a4u_lic_reset_stats' ) ); ?>" onclick="return confirm('Reset all counters?');">Reset counters</a></p>
			<p style="color:#666;">No personal data is counted.</p>

		<?php elseif ( 'sync' === $tab ) :
			$log = (array) get_option( 'a4u_lic_sync_log', array() ); $pending = get_option( 'a4u_lic_pending' );
			$su  = wp_nonce_url( admin_url( 'admin-post.php?action=a4u_lic_sync' ), 'a4u_lic_sync' );
			?>
			<p style="max-width:860px;">Every week a GitHub Action reads the official LIC sales brochures (with Gemini), archives each PDF and publishes <code>lic-plans.json</code>. This site checks it daily. Nothing changes on the live calculator until you click <strong>Approve</strong>.</p>
			<table class="widefat striped" style="max-width:700px;"><tbody>
				<tr><td>Last check</td><td><?php echo esc_html( $log['checked_at'] ?? 'never' ); ?> &mdash; <?php echo esc_html( $log['msg'] ?? '' ); ?></td></tr>
				<tr><td>LIC data version (applied / latest)</td><td><?php echo (int) get_option( 'a4u_lic_sync_applied', 0 ); ?> / <?php echo (int) ( $log['remote'] ?? 0 ); ?> <span style="color:#666;">(pipeline checked LIC on <?php echo esc_html( $log['remote_checked'] ?? '?' ); ?>)</span></td></tr>
				<tr><td>Source</td><td><code><?php echo esc_html( $d['settings']['sync_url'] ); ?></code></td></tr>
			</tbody></table>
			<p><a class="button" href="<?php echo esc_url( add_query_arg( 'do', 'check', $su ) ); ?>">Check now</a></p>
			<?php if ( is_array( $pending ) ) : ?>
				<h2>Pending update v<?php echo (int) $pending['version']; ?> <small style="font-weight:400;color:#666;">fetched <?php echo esc_html( $pending['fetched'] ); ?></small></h2>
				<table class="widefat striped" style="max-width:1000px;"><thead><tr><th>Plan</th><th>Field</th><th>Current</th><th>New (from LIC brochure)</th></tr></thead><tbody>
				<?php foreach ( $pending['diff'] as $r ) : ?><tr><td><?php echo esc_html( $r[0] ); ?></td><td><code><?php echo esc_html( $r[1] ); ?></code></td><td style="color:#b32d2e;word-break:break-all;"><?php echo esc_html( $r[2] ); ?></td><td style="color:#00701a;word-break:break-all;"><?php echo esc_html( $r[3] ); ?></td></tr><?php endforeach; ?>
				</tbody></table>
				<p><a class="button button-primary" href="<?php echo esc_url( add_query_arg( 'do', 'approve', $su ) ); ?>" onclick="return confirm('Apply these LIC brochure changes to the live calculator?');">Approve &amp; apply</a> <a class="button" href="<?php echo esc_url( add_query_arg( 'do', 'dismiss', $su ) ); ?>">Dismiss</a></p>
				<p style="color:#666;">CSV rates, Verified flag, bonus rates and Active status are never changed by sync. New plans arrive switched off.</p>
			<?php else : ?><p><em>No pending changes.</em></p><?php endif; ?>

		<?php elseif ( 'settings' === $tab ) : $s = $d['settings']; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:760px;">
				<input type="hidden" name="action" value="a4u_lic_settings">
				<?php wp_nonce_field( 'a4u_lic_settings', 'a4u_nonce' ); ?>
				<table class="form-table" role="presentation"><tbody>
					<tr><th>GST % (default)</th><td><input type="number" min="0" max="28" step="0.01" name="gst" value="<?php echo esc_attr( $s['gst'] ); ?>" style="width:90px"> <span style="color:#666;">Individual life premiums: 0% since 22 Sept 2025.</span></td></tr>
					<tr><th>Fallback modal factors</th><td>Half-yearly <input type="number" min="0.01" max="1" step="0.001" name="m_half" value="<?php echo esc_attr( $s['modal']['half'] ); ?>" style="width:80px"> Quarterly <input type="number" min="0.01" max="1" step="0.001" name="m_quarter" value="<?php echo esc_attr( $s['modal']['quarter'] ); ?>" style="width:80px"> Monthly <input type="number" min="0.01" max="1" step="0.001" name="m_month" value="<?php echo esc_attr( $s['modal']['month'] ); ?>" style="width:80px"><p style="color:#666;margin:2px 0 0;">Used only by plans without a mode rebate setting.</p></td></tr>
					<tr><th>Rider flat rates (fallback)</th><td>Accident Benefit <input type="number" min="0" max="50" step="0.01" name="rider" value="<?php echo esc_attr( $s['rider_per_1000'] ); ?>" style="width:70px"> / 1000 rider SA &nbsp; AD&amp;DB <input type="number" min="0" max="50" step="0.01" name="rider_addb" value="<?php echo esc_attr( $s['rider_addb'] ); ?>" style="width:70px"> / 1000 BSA<br>Term rider <input type="number" min="0" max="50" step="0.01" name="rider_term" value="<?php echo esc_attr( $s['rider_term'] ); ?>" style="width:70px"> / 1000 rider SA &nbsp; PWB <input type="number" min="0" max="50" step="0.01" name="rider_pwb_pct" value="<?php echo esc_attr( $s['rider_pwb_pct'] ); ?>" style="width:70px"> % of base premium</td></tr>
					<tr><th>Rider rates CSV (exact)</th><td><textarea name="rider_csv" rows="5" style="width:100%;font-family:monospace;" placeholder="adb,30,20,0.50&#10;term,30,20,1.42&#10;pwb,35,15,2.10"><?php echo esc_textarea( $s['rider_csv'] ); ?></textarea><p style="color:#666;margin:2px 0 0;"><code>rider,age,term,rate</code> &mdash; rider = adb / addb / term / pwb. Rate is per 1000 (pwb: % of base premium, age = proposer age). Missing rows use the flat rate above.</p></td></tr>
					<tr><th colspan="2"><h3 style="margin:10px 0 0;">PDF branding &amp; IRDAI details</h3></th></tr>
					<?php foreach ( array( 'brand_name' => 'Business name', 'agent_name' => 'Agent name (as per licence)', 'agent_type' => 'Agent type', 'agency_code' => 'Agency code', 'agency_branch' => 'Branch', 'brand_phone' => 'Phone', 'brand_email' => 'Email', 'brand_web' => 'Website', 'logo_url' => 'Logo URL (blank = built-in)', 'color_gold' => 'Accent colour', 'color_green' => 'Main colour' ) as $bk => $bl ) : ?>
					<tr><th><?php echo esc_html( $bl ); ?></th><td><input type="text" name="<?php echo esc_attr( $bk ); ?>" value="<?php echo esc_attr( $s[ $bk ] ?? '' ); ?>" style="width:100%"></td></tr>
					<?php endforeach; ?>
					<tr><th colspan="2"><h3 style="margin:10px 0 0;">Data sync &amp; updates</h3></th></tr>
					<tr><th>LIC data JSON URL</th><td><input type="url" name="sync_url" value="<?php echo esc_attr( $s['sync_url'] ); ?>" style="width:100%"></td></tr>
					<tr><th>Plugin update JSON URL</th><td><input type="url" name="update_url" value="<?php echo esc_attr( $s['update_url'] ); ?>" style="width:100%"></td></tr>
					<tr><th>WhatsApp number</th><td><input type="text" name="whatsapp" value="<?php echo esc_attr( $s['whatsapp'] ); ?>" style="width:160px"> (country code + number)</td></tr>
					<tr><th>Lead retention (days)</th><td><input type="number" min="30" max="1095" name="retention_days" value="<?php echo (int) $s['retention_days']; ?>" style="width:90px"></td></tr>
					<tr><th>Calculator page slug</th><td><input type="text" name="base_slug" value="<?php echo esc_attr( $s['base_slug'] ); ?>" style="width:200px"> <span style="color:#666;">Plan pages auto-work at <code>/<?php echo esc_html( $s['base_slug'] ); ?>/714/</code></span></td></tr>
					<tr><th>FAQ section</th><td><label><input type="checkbox" name="faq" value="1" <?php checked( ! empty( $s['faq'] ), true ); ?>> Show FAQ below calculator + FAQPage schema</label></td></tr>
					<tr><th>Related links (Label|URL per line)</th><td><textarea name="links" rows="4" style="width:100%;"><?php echo esc_textarea( $s['links'] ); ?></textarea></td></tr>
				</tbody></table>
				<?php submit_button( 'Save settings' ); ?>
			</form>
		<?php endif; ?>
	</div>
	<?php
}

/* =====================================================================
 * 5. Admin: form handlers
 * ===================================================================== */

function a4u_lic_parse_csv( $text, $p ) {
	$rows    = array();
	$errors  = array();
	$allowed = a4u_lic_plan_terms( $p );
	foreach ( preg_split( '/\r\n|\r|\n/', trim( $text ) ) as $n => $line ) {
		$line = trim( $line );
		if ( '' === $line ) { continue; }
		$c  = array_map( 'trim', explode( ',', $line ) );
		$ln = 'Line ' . ( $n + 1 ) . ': ';
		if ( count( $c ) < 3 || ! is_numeric( $c[0] ) || ! is_numeric( $c[1] ) || ! is_numeric( $c[2] ) ) {
			if ( 0 === $n ) { continue; }
			$errors[] = $ln . 'need age,term,rate';
			continue;
		}
		$age  = (int) $c[0];
		$term = (int) $c[1];
		$rate = (float) $c[2];
		if ( $rate <= 0 || $rate > 1500 ) { $errors[] = $ln . 'rate out of range'; continue; }
		if ( $age < (int) $p['min_age'] || $age > (int) $p['max_age'] ) { $errors[] = $ln . "age {$age} outside {$p['min_age']}-{$p['max_age']}"; continue; }
		if ( $allowed && ! in_array( $term, $allowed, true ) ) { $errors[] = $ln . "term {$term} not allowed for this plan"; continue; }
		$key = $age . '|' . $term;
		if ( isset( $rows[ $key ] ) ) { $errors[] = $ln . "duplicate age {$age} / term {$term}"; continue; }
		$rows[ $key ] = $rate;
	}
	return array( $rows, $errors );
}

function a4u_lic_snapshot( $p, $version ) {
	return array(
		'version'   => (int) $version,
		'rates'     => $p['rates'],
		'source'    => $p['source'],
		'effective' => $p['effective'],
		'verified'  => (int) $p['verified'],
		'updated'   => $p['rates_updated'] ?? $p['updated'],
	);
}

add_action( 'admin_post_a4u_lic_save_plan', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_save_plan', 'a4u_nonce' );
	$post = wp_unslash( $_POST ); // phpcs:ignore
	$d    = a4u_lic_data();
	$id   = sanitize_key( $post['plan'] ?? '' );
	if ( ! isset( $d['plans'][ $id ] ) ) { wp_die( 'Unknown plan' ); }
	$p        = $d['plans'][ $id ];
	$errors   = array();
	$snapshot = a4u_lic_snapshot( $p, $d['rate_version'] );

	$p['active'] = isset( $post['active'] ) ? 1 : 0;
	$min_age     = max( 0, min( 99, (int) ( $post['min_age'] ?? $p['min_age'] ) ) );
	$max_age     = max( 0, min( 99, (int) ( $post['max_age'] ?? $p['max_age'] ) ) );
	if ( $min_age > $max_age ) {
		$errors[] = 'Min age cannot be more than max age (ages not changed).';
	} else {
		$p['min_age'] = $min_age;
		$p['max_age'] = $max_age;
	}
	$p['min_sa']       = max( 1000, (int) ( $post['min_sa'] ?? $p['min_sa'] ) );
	$p['max_maturity'] = max( 18, min( 100, (int) ( $post['max_maturity'] ?? $p['max_maturity'] ) ) );
	$p['fab_min_term'] = max( 0, min( 100, (int) ( $post['fab_min_term'] ?? $p['fab_min_term'] ) ) );
	foreach ( array( 'srb', 'fab' ) as $k ) { $p[ $k ] = max( 0, min( 1000, (float) ( $post[ $k ] ?? $p[ $k ] ) ) ); }

	$slabs = a4u_lic_text_to_slabs( $post['sa_slabs'] ?? '' );
	if ( $slabs ) { $p['sa_slabs'] = $slabs; } else { $errors[] = 'SA multiples format: 200000:5000, 450001:50000 (not changed).'; }
	if ( isset( $post['rebate_slabs'] ) ) { $p['rebate_slabs'] = a4u_lic_text_to_pairs( $post['rebate_slabs'] ); }
	if ( isset( $post['mode_adj'] ) ) {
		$m = a4u_lic_text_to_mode( $post['mode_adj'] );
		if ( 4 === count( $m ) ) { $p['mode_adj'] = $m; } else { $errors[] = 'Mode format: yearly:-2, half:-1, quarter:0, month:0 (not changed).'; }
	}
	$p['bonus_bands'] = a4u_lic_text_to_pairs( $post['bonus_bands'] ?? '', 3 );
	$p['death_pct']   = max( 0, min( 500, (int) ( $post['death_pct'] ?? 0 ) ) );
	$p['riders']      = array_values( array_intersect( array( 'adb', 'addb', 'term', 'pwb' ), (array) ( $post['riders'] ?? array() ) ) );
	$p['sample_sa']   = max( 0, (int) ( $post['sample_sa'] ?? 0 ) );
	$p['samples']     = a4u_lic_text_to_samples( $post['samples'] ?? '' );
	$p['source']      = sanitize_text_field( $post['source'] ?? '' );
	$eff              = sanitize_text_field( $post['effective'] ?? '' );
	if ( '' !== $eff && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $eff ) ) {
		$errors[] = 'Effective date must be YYYY-MM-DD.';
		$eff      = '';
	}
	$p['effective'] = $eff;

	$csv = trim( (string) ( $post['csv'] ?? '' ) );
	if ( '' !== $csv ) {
		list( $rows, $csv_err ) = a4u_lic_parse_csv( $csv, $p );
		if ( $csv_err ) {
			$errors = array_merge( $errors, array( 'CSV not imported' ), array_slice( $csv_err, 0, 5 ) );
		} elseif ( ! $rows ) {
			$errors[] = 'No valid rows found.';
		} else {
			array_unshift( $p['history'], $snapshot );
			$p['history']       = array_slice( (array) $p['history'], 0, 5 );
			$p['rates']         = $rows;
			$p['rates_updated'] = current_time( 'mysql' );
		}
	}

	$want          = isset( $post['verified'] );
	$p['verified'] = ( $want && '' !== $p['source'] && '' !== $p['effective'] && ! empty( $p['rates'] ) ) ? 1 : 0;
	if ( $want && ! $p['verified'] ) { $errors[] = 'Verified needs Source + Effective date + at least 1 CSV rate row.'; }

	$p['updated']      = current_time( 'mysql' );
	$d['plans'][ $id ] = $p;
	a4u_lic_save( $d );
	a4u_lic_flash( 'plan ' . $id, $errors ? array( $id => implode( ' | ', $errors ) ) : array() );
	wp_safe_redirect( admin_url( 'admin.php?page=a4u-lic' ) );
	exit;
} );

add_action( 'admin_post_a4u_lic_restore', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_restore' );
	$d  = a4u_lic_data();
	$id = sanitize_key( $_GET['plan'] ?? '' ); // phpcs:ignore
	$i  = (int) ( $_GET['idx'] ?? -1 ); // phpcs:ignore
	if ( isset( $d['plans'][ $id ]['history'][ $i ] ) ) {
		$p = $d['plans'][ $id ];
		$h = $p['history'][ $i ];
		array_unshift( $p['history'], a4u_lic_snapshot( $p, $d['rate_version'] ) );
		$p['history']       = array_slice( $p['history'], 0, 5 );
		$p['rates']         = a4u_lic_rates_to_map( $h['rates'] ?? array() );
		$p['source']        = (string) ( $h['source'] ?? '' );
		$p['effective']     = (string) ( $h['effective'] ?? '' );
		$p['verified']      = ( ! empty( $h['verified'] ) && '' !== $p['source'] && '' !== $p['effective'] && ! empty( $p['rates'] ) ) ? 1 : 0;
		$p['rates_updated'] = current_time( 'mysql' );
		$p['updated']       = current_time( 'mysql' );
		$d['plans'][ $id ]  = $p;
		a4u_lic_save( $d );
		a4u_lic_flash( 'restored ' . $id );
	}
	wp_safe_redirect( admin_url( 'admin.php?page=a4u-lic' ) );
	exit;
} );

add_action( 'admin_post_a4u_lic_settings', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_settings', 'a4u_nonce' );
	$post  = wp_unslash( $_POST ); // phpcs:ignore
	$d     = a4u_lic_data();
	$s     = $d['settings'];
	$clamp = function ( $v, $min, $max, $def ) {
		$v = is_numeric( $v ) ? (float) $v : $def;
		return max( $min, min( $max, $v ) );
	};
	$s['gst']              = $clamp( $post['gst'] ?? 0, 0, 28, 0 );
	$s['modal']['yearly']  = 1;
	$s['modal']['half']    = $clamp( $post['m_half'] ?? null, 0.01, 1, 0.51 );
	$s['modal']['quarter'] = $clamp( $post['m_quarter'] ?? null, 0.01, 1, 0.26 );
	$s['modal']['month']   = $clamp( $post['m_month'] ?? null, 0.01, 1, 0.087 );
	$s['rider_per_1000']   = $clamp( $post['rider'] ?? null, 0, 50, 0.5 );
	$s['rider_addb']       = $clamp( $post['rider_addb'] ?? null, 0, 50, 1 );
	$s['rider_term']       = $clamp( $post['rider_term'] ?? null, 0, 50, 1.5 );
	$s['rider_pwb_pct']    = $clamp( $post['rider_pwb_pct'] ?? null, 0, 50, 2 );
	// rider CSV: फक्त बरोबर ओळी ठेव
	$keep = array();
	foreach ( a4u_lic_rider_map( $post['rider_csv'] ?? '' ) as $k => $v ) { $keep[] = str_replace( '|', ',', $k ) . ',' . $v; }
	$s['rider_csv']      = implode( "\n", $keep );
	$s['retention_days'] = (int) $clamp( $post['retention_days'] ?? null, 30, 1095, 180 );
	$s['faq']            = isset( $post['faq'] ) ? 1 : 0;
	$new_slug            = sanitize_title( $post['base_slug'] ?? 'lic-calculator' );
	if ( '' !== $new_slug && $new_slug !== $s['base_slug'] ) { update_option( 'a4u_lic_flush', 1, false ); }
	$s['base_slug'] = '' !== $new_slug ? $new_slug : 'lic-calculator';
	$s['whatsapp']  = preg_replace( '/\D/', '', (string) ( $post['whatsapp'] ?? '' ) );
	foreach ( array( 'brand_name', 'agent_name', 'agent_type', 'agency_code', 'agency_branch', 'brand_phone', 'brand_web' ) as $bk ) { $s[ $bk ] = sanitize_text_field( $post[ $bk ] ?? '' ); }
	$s['brand_email'] = sanitize_email( $post['brand_email'] ?? '' );
	$s['logo_url']    = esc_url_raw( $post['logo_url'] ?? '' );
	foreach ( array( 'color_gold' => '#B8924A', 'color_green' => '#3F5A22' ) as $ck => $cd ) { $s[ $ck ] = sanitize_hex_color( $post[ $ck ] ?? '' ) ?: $cd; }
	$s['sync_url']   = esc_url_raw( $post['sync_url'] ?? '' );
	$s['update_url'] = esc_url_raw( $post['update_url'] ?? '' );
	delete_transient( 'a4u_lic_update_info' );
	$links          = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $post['links'] ?? '' ) ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line, 2 ) );
		if ( 2 === count( $parts ) && '' !== $parts[0] && esc_url_raw( $parts[1] ) ) {
			$links[] = sanitize_text_field( $parts[0] ) . '|' . esc_url_raw( $parts[1] );
		}
	}
	$s['links']    = implode( "\n", $links );
	$d['settings'] = $s;
	a4u_lic_save( $d );
	a4u_lic_flash( 'settings' );
	wp_safe_redirect( admin_url( 'admin.php?page=a4u-lic&tab=settings' ) );
	exit;
} );

add_action( 'admin_post_a4u_lic_del_lead', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_del_lead' );
	global $wpdb;
	$lid = absint( $_GET['id'] ?? 0 ); // phpcs:ignore
	if ( $lid ) { $wpdb->delete( a4u_lic_table( 'leads' ), array( 'id' => $lid ), array( '%d' ) ); }
	a4u_lic_flash( 'lead deleted' );
	wp_safe_redirect( admin_url( 'admin.php?page=a4u-lic&tab=leads' ) );
	exit;
} );

function a4u_lic_csv_cell( $v ) {
	$v = (string) $v;
	return ( '' !== $v && false !== strpos( "=+-@\t\r", $v[0] ) ) ? "'" . $v : $v;
}

add_action( 'admin_post_a4u_lic_export_leads', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_export' );
	global $wpdb;
	$t    = a4u_lic_table( 'leads' );
	$rows = $wpdb->get_results( "SELECT created, name, mobile, plan, sa, premium FROM {$t} ORDER BY id DESC", ARRAY_A ); // phpcs:ignore
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=a4u-lic-leads-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array( 'date', 'name', 'mobile', 'plan', 'sa', 'premium' ) );
	foreach ( (array) $rows as $l ) { fputcsv( $out, array_map( 'a4u_lic_csv_cell', array_values( $l ) ) ); }
	fclose( $out );
	exit;
} );

add_action( 'admin_post_a4u_lic_reset_stats', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_reset_stats' );
	global $wpdb;
	$wpdb->query( 'DELETE FROM ' . a4u_lic_table( 'stats' ) ); // phpcs:ignore
	a4u_lic_flash( 'stats reset' );
	wp_safe_redirect( admin_url( 'admin.php?page=a4u-lic&tab=stats' ) );
	exit;
} );

/* =====================================================================
 * 6. REST API
 * ===================================================================== */

function a4u_lic_throttle( $bucket, $max, $window ) {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	$key = 'a4u_lic_' . $bucket . '_' . md5( $ip . wp_salt( 'nonce' ) );
	$n   = (int) get_transient( $key );
	if ( $n >= $max ) { return false; }
	set_transient( $key, $n + 1, $window );
	return true;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'a4u-lic/v1', '/plan/(?P<id>[a-z0-9_-]+)', array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'a4u_lic_rest_plan' ) );
	register_rest_route( 'a4u-lic/v1', '/track', array( 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'a4u_lic_rest_track' ) );
	register_rest_route( 'a4u-lic/v1', '/lead', array( 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'a4u_lic_rest_lead' ) );
} );

function a4u_lic_rest_plan( WP_REST_Request $req ) {
	$d  = a4u_lic_data();
	$id = sanitize_key( $req['id'] );
	if ( empty( $d['plans'][ $id ]['active'] ) ) {
		return new WP_Error( 'not_found', 'Plan not found', array( 'status' => 404 ) );
	}
	$res = rest_ensure_response( array( 'id' => $id, 'version' => (int) $d['rate_version'], 'rates' => (object) $d['plans'][ $id ]['rates'] ) );
	$res->header( 'Cache-Control', 'public, max-age=3600' );
	return $res;
}

function a4u_lic_rest_track( WP_REST_Request $req ) {
	$e = sanitize_key( (string) $req->get_param( 'event' ) );
	if ( ! in_array( $e, array( 'calculate', 'compare', 'pdf', 'whatsapp' ), true ) ) {
		return new WP_Error( 'bad_event', 'Invalid event', array( 'status' => 400 ) );
	}
	if ( a4u_lic_throttle( 't', 120, HOUR_IN_SECONDS ) ) { a4u_lic_stat_add( $e ); }
	return array( 'ok' => 1 );
}

function a4u_lic_rest_lead( WP_REST_Request $req ) {
	if ( '' !== (string) $req->get_param( 'company' ) ) { return array( 'ok' => 1, 'message' => 'Thank you!' ); }
	$consent = (int) $req->get_param( 'consent' );
	$name    = sanitize_text_field( (string) $req->get_param( 'name' ) );
	$mobile  = preg_replace( '/\D/', '', (string) $req->get_param( 'mobile' ) );
	if ( 12 === strlen( $mobile ) && 0 === strpos( $mobile, '91' ) ) { $mobile = substr( $mobile, 2 ); }
	if ( 1 !== $consent || '' === $name || strlen( $name ) > 100 || ! preg_match( '/^[6-9]\d{9}$/', $mobile ) ) {
		return new WP_Error( 'invalid', 'Please enter your name, a valid 10-digit mobile number and tick the consent box.', array( 'status' => 400 ) );
	}
	if ( ! a4u_lic_throttle( 'l', 3, 10 * MINUTE_IN_SECONDS ) ) {
		return new WP_Error( 'too_many', 'Too many requests. Please try again after some time.', array( 'status' => 429 ) );
	}
	global $wpdb;
	$ok = $wpdb->insert(
		a4u_lic_table( 'leads' ),
		array(
			'created' => current_time( 'mysql' ),
			'name'    => $name,
			'mobile'  => $mobile,
			'plan'    => substr( sanitize_text_field( (string) $req->get_param( 'plan' ) ), 0, 100 ),
			'sa'      => absint( $req->get_param( 'sa' ) ),
			'premium' => round( (float) $req->get_param( 'premium' ), 2 ),
		),
		array( '%s', '%s', '%s', '%s', '%d', '%f' )
	);
	if ( ! $ok ) {
		return new WP_Error( 'db', 'Could not save right now. Please contact us on WhatsApp.', array( 'status' => 500 ) );
	}
	a4u_lic_stat_add( 'lead' );
	return array( 'ok' => 1, 'message' => 'Thank you! Our advisor will contact you shortly.' );
}

/* =====================================================================
 * 6b. Data sync — GitHub pipeline चा lic-plans.json (रोज), admin Approve नंतरच लागू
 * ===================================================================== */

// JSON मधून कोणत्या keys येऊ शकतात (rates, verified, bonus, active कधीच नाही)
function a4u_lic_sync_keys() {
	return array( 'uin', 'min_age', 'max_age', 'min_sa', 'max_maturity', 'min_maturity', 'terms', 'ppt_map', 'ppt_options', 'ppt_max_age_sum',
		'maturity_age', 'survival_pct', 'ga_per_1000', 'min_age_by_term', 'sa_slabs', 'rebate_slabs', 'rebate_bands', 'mode_adj', 'death_pct',
		'samples', 'sample_sa', 'brochure' );
}

function a4u_lic_sync_check( $manual = false ) {
	$d   = a4u_lic_data();
	$url = (string) ( $d['settings']['sync_url'] ?? '' );
	$log = array( 'checked_at' => current_time( 'mysql' ), 'ok' => 0, 'msg' => '' );
	if ( '' === $url ) { $log['msg'] = 'Sync URL empty'; update_option( 'a4u_lic_sync_log', $log, false ); return $log; }
	$res = wp_remote_get( add_query_arg( 'nc', time(), $url ), array( 'timeout' => 20 ) );
	if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
		$log['msg'] = 'Download failed: ' . ( is_wp_error( $res ) ? $res->get_error_message() : wp_remote_retrieve_response_code( $res ) );
		update_option( 'a4u_lic_sync_log', $log, false );
		return $log;
	}
	$json = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( ! is_array( $json ) || empty( $json['plans'] ) || ! is_array( $json['plans'] ) ) {
		$log['msg'] = 'Invalid JSON';
		update_option( 'a4u_lic_sync_log', $log, false );
		return $log;
	}
	$applied = (int) get_option( 'a4u_lic_sync_applied', 0 );
	$log['ok']       = 1;
	$log['remote']   = (int) ( $json['version'] ?? 0 );
	$log['remote_checked'] = (string) ( $json['checked_at'] ?? '' );
	$diff = a4u_lic_sync_diff( $d, $json );
	if ( $log['remote'] > $applied && $diff ) {
		update_option( 'a4u_lic_pending', array( 'version' => $log['remote'], 'json' => $json, 'diff' => $diff, 'fetched' => current_time( 'mysql' ) ), false );
		$log['msg'] = count( $diff ) . ' change(s) waiting for approval';
	} else {
		if ( $log['remote'] > $applied ) { update_option( 'a4u_lic_sync_applied', $log['remote'], false ); }
		delete_option( 'a4u_lic_pending' );
		$log['msg'] = 'Up to date';
	}
	update_option( 'a4u_lic_sync_log', $log, false );
	return $log;
}
add_action( 'a4u_lic_sync', function () { a4u_lic_sync_check(); } );

// [plan, field, old, new] यादी
function a4u_lic_sync_diff( $d, $json ) {
	$out = array();
	foreach ( $json['plans'] as $id => $np ) {
		$id = sanitize_key( (string) $id );
		if ( ! is_array( $np ) ) { continue; }
		if ( ! isset( $d['plans'][ $id ] ) ) {
			$out[] = array( $id, 'NEW PLAN', '', (string) ( $np['name'] ?? '' ) . ' (' . (string) ( $np['type'] ?? '?' ) . ')' );
			continue;
		}
		foreach ( a4u_lic_sync_keys() as $k ) {
			if ( ! array_key_exists( $k, $np ) ) { continue; }
			$old = $d['plans'][ $id ][ $k ] ?? null;
			if ( wp_json_encode( $old ) !== wp_json_encode( $np[ $k ] ) && json_encode( a4u_lic_num_norm( $old ) ) !== json_encode( a4u_lic_num_norm( $np[ $k ] ) ) ) {
				$out[] = array( $id, $k, a4u_lic_short( $old ), a4u_lic_short( $np[ $k ] ) );
			}
		}
	}
	return $out;
}
// 2 आणि 2.0 सारखे फरक दुर्लक्षित करण्यासाठी
function a4u_lic_num_norm( $v ) {
	if ( is_array( $v ) ) { return array_map( 'a4u_lic_num_norm', $v ); }
	return is_numeric( $v ) ? 0 + $v : $v;
}
function a4u_lic_short( $v ) {
	$t = is_scalar( $v ) || null === $v ? (string) $v : wp_json_encode( $v );
	return strlen( $t ) > 140 ? substr( $t, 0, 137 ) . '...' : $t;
}

function a4u_lic_sync_apply() {
	$pending = get_option( 'a4u_lic_pending' );
	if ( ! is_array( $pending ) || empty( $pending['json']['plans'] ) ) { return 0; }
	$d     = a4u_lic_data();
	$types = array( 'endowment', 'anand', 'lakshya', 'labh', 'umang', 'single', 'utsav', 'utsav_sp' );
	$n     = 0;
	foreach ( $pending['json']['plans'] as $id => $np ) {
		$id = sanitize_key( (string) $id );
		if ( ! is_array( $np ) ) { continue; }
		if ( ! isset( $d['plans'][ $id ] ) ) {
			if ( empty( $np['type'] ) || ! in_array( $np['type'], $types, true ) || empty( $np['name'] ) ) { continue; }
			$base             = a4u_lic_default_plans()['714'];
			$base             = array_merge( $base, array( 'name' => sanitize_text_field( $np['name'] ), 'type' => $np['type'], 'active' => 0, 'samples' => array(), 'rates' => array(), 'history' => array() ) );
			$d['plans'][ $id ] = $base; // नवीन plan बंद (inactive) स्थितीत येतो — admin ने तपासून चालू करायचा
		}
		foreach ( a4u_lic_sync_keys() as $k ) {
			if ( array_key_exists( $k, $np ) ) { $d['plans'][ $id ][ $k ] = $np[ $k ]; }
		}
		$d['plans'][ $id ]['source']    = 'LIC sales brochure (auto-sync v' . (int) $pending['version'] . ')';
		$d['plans'][ $id ]['effective'] = substr( (string) ( $np['extracted_at'] ?? $pending['json']['checked_at'] ?? '' ), 0, 10 );
		$n++;
	}
	a4u_lic_save( $d );
	update_option( 'a4u_lic_sync_applied', (int) $pending['version'], false );
	delete_option( 'a4u_lic_pending' );
	return $n;
}

add_action( 'admin_post_a4u_lic_sync', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed' ); }
	check_admin_referer( 'a4u_lic_sync' );
	$do = sanitize_key( $_GET['do'] ?? 'check' ); // phpcs:ignore
	if ( 'approve' === $do ) {
		a4u_lic_flash( 'LIC data applied to ' . a4u_lic_sync_apply() . ' plan(s)' );
	} elseif ( 'dismiss' === $do ) {
		$pending = get_option( 'a4u_lic_pending' );
		if ( is_array( $pending ) ) { update_option( 'a4u_lic_sync_applied', (int) $pending['version'], false ); }
		delete_option( 'a4u_lic_pending' );
		a4u_lic_flash( 'pending update dismissed' );
	} else {
		$log = a4u_lic_sync_check( true );
		a4u_lic_flash( 'sync check: ' . $log['msg'] );
	}
	wp_safe_redirect( admin_url( 'admin.php?page=a4u-lic&tab=sync' ) );
	exit;
} );

/* =====================================================================
 * 6c. Plugin auto-update (S6) — GitHub वरचा update.json
 * ===================================================================== */

function a4u_lic_remote_info( $force = false ) {
	$info = $force ? false : get_transient( 'a4u_lic_update_info' );
	if ( false === $info ) {
		$d   = a4u_lic_data();
		$url = (string) ( $d['settings']['update_url'] ?? '' );
		$info = array();
		if ( '' !== $url ) {
			$res = wp_remote_get( add_query_arg( 'nc', time(), $url ), array( 'timeout' => 15 ) );
			if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
				$j = json_decode( wp_remote_retrieve_body( $res ), true );
				if ( is_array( $j ) && ! empty( $j['version'] ) && ! empty( $j['download_url'] ) ) { $info = $j; }
			}
		}
		set_transient( 'a4u_lic_update_info', $info, 6 * HOUR_IN_SECONDS );
	}
	return $info;
}

add_filter( 'pre_set_site_transient_update_plugins', function ( $t ) {
	if ( ! is_object( $t ) ) { return $t; }
	$info = a4u_lic_remote_info();
	$file = plugin_basename( A4U_LIC_FILE );
	if ( $info && version_compare( $info['version'], A4U_LIC_VER, '>' ) ) {
		$t->response[ $file ] = (object) array(
			'slug'        => 'a4u-lic-calculator',
			'plugin'      => $file,
			'new_version' => $info['version'],
			'package'     => $info['download_url'],
			'url'         => 'https://www.advisor4u.in/lic-calculator/',
			'tested'      => $info['tested'] ?? '',
			'requires'    => $info['requires'] ?? '',
		);
	} elseif ( isset( $t->response[ $file ] ) ) {
		unset( $t->response[ $file ] );
	}
	return $t;
} );

add_filter( 'plugins_api', function ( $res, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || 'a4u-lic-calculator' !== $args->slug ) { return $res; }
	$info = a4u_lic_remote_info();
	if ( ! $info ) { return $res; }
	return (object) array(
		'name'          => 'A4U LIC Calculator',
		'slug'          => 'a4u-lic-calculator',
		'version'       => $info['version'],
		'author'        => 'Sahare Financial Services',
		'download_link' => $info['download_url'],
		'last_updated'  => $info['last_updated'] ?? '',
		'sections'      => array( 'changelog' => wp_kses_post( $info['changelog'] ?? '' ) ),
	);
}, 10, 3 );

/* =====================================================================
 * 7. Frontend: shortcode
 * ===================================================================== */

add_action( 'wp_enqueue_scripts', function () {
	$url = plugin_dir_url( A4U_LIC_FILE );
	wp_register_style( 'a4u-lic', $url . 'assets/a4u-lic.css', array(), A4U_LIC_VER );
	wp_register_script( 'a4u-lic', $url . 'assets/a4u-lic.js', array(), A4U_LIC_VER, true );
} );

add_shortcode( 'a4u_lic_calculator', function ( $atts = array() ) {
	$atts  = shortcode_atts( array( 'plan' => '', 'title' => '' ), $atts, 'a4u_lic_calculator' );
	$d     = a4u_lic_data();
	$s     = $d['settings'];
	$plans = array();
	foreach ( $d['plans'] as $id => $p ) {
		if ( empty( $p['active'] ) ) { continue; }
		$plans[] = array(
			'id'              => (string) $id,
			'name'            => $p['name'],
			'type'            => $p['type'],
			'min_age'         => (int) $p['min_age'],
			'max_age'         => (int) $p['max_age'],
			'min_sa'          => (int) $p['min_sa'],
			'max_maturity'    => (int) $p['max_maturity'],
			'min_maturity'    => (int) ( $p['min_maturity'] ?? 0 ),
			'terms'           => a4u_lic_plan_terms( $p ),
			'ppt_map'         => (object) ( $p['ppt_map'] ?? array() ),
			'ppt_max_age_sum' => (int) ( $p['ppt_max_age_sum'] ?? 0 ),
			'maturity_age'    => (int) ( $p['maturity_age'] ?? 100 ),
			'survival_pct'    => (float) ( $p['survival_pct'] ?? 0 ),
			'tail_age'        => (int) ( $p['tail_age'] ?? 0 ),
			'min_age_by_term' => (object) ( $p['min_age_by_term'] ?? array() ),
			'sa_slabs'        => array_values( (array) ( $p['sa_slabs'] ?? array() ) ),
			'rebate_slabs'    => array_values( (array) ( $p['rebate_slabs'] ?? array() ) ),
			'rebate_bands'    => array_values( (array) ( $p['rebate_bands'] ?? array() ) ),
			'mode_adj'        => (object) ( $p['mode_adj'] ?? array() ),
			'srb'             => (float) $p['srb'],
			'fab'             => (float) $p['fab'],
			'fab_min_term'    => (int) $p['fab_min_term'],
			'bonus_bands'     => array_values( (array) ( $p['bonus_bands'] ?? array() ) ),
			'death_pct'       => (int) ( $p['death_pct'] ?? 0 ),
			'death_sp'        => array_values( (array) ( $p['death_sp'] ?? array() ) ),
			'riders'          => array_values( (array) ( $p['riders'] ?? array() ) ),
			'ga_per_1000'     => (float) ( $p['ga_per_1000'] ?? 0 ),
			'samples'         => array_values( (array) ( $p['samples'] ?? array() ) ),
			'sample_sa'       => (int) ( $p['sample_sa'] ?? 0 ),
			'closed'          => (int) ( $p['closed'] ?? 0 ),
			'verified'        => (int) $p['verified'],
			'has_rates'       => ! empty( $p['rates'] ),
			'effective'       => (string) $p['effective'],
			'brochure'        => (string) ( $p['brochure'] ?? '' ),
			'uin'             => (string) ( $p['uin'] ?? '' ),
		);
	}
	$links = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $s['links'] ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line, 2 ) );
		if ( 2 === count( $parts ) && '' !== $parts[0] && esc_url_raw( $parts[1] ) ) {
			$links[] = array( 'label' => $parts[0], 'url' => esc_url_raw( $parts[1] ) );
		}
	}
	$init = sanitize_key( $atts['plan'] );
	if ( '' === $init ) { $init = sanitize_key( (string) get_query_var( 'a4u_plan' ) ); }
	$title = sanitize_text_field( $atts['title'] );
	$cp    = a4u_lic_current_plan();
	if ( '' === $title && $cp ) { $title = 'LIC ' . $cp[1]['name'] . ' Premium Calculator'; }
	$cfg = array(
		'rest'       => esc_url_raw( rest_url( 'a4u-lic/v1/' ) ),
		'version'    => (int) $d['rate_version'],
		'gst'        => (float) $s['gst'],
		'modal'      => $s['modal'],
		'riderRates' => array( 'adb' => (float) $s['rider_per_1000'], 'addb' => (float) ( $s['rider_addb'] ?? 1 ), 'term' => (float) ( $s['rider_term'] ?? 1.5 ), 'pwb' => (float) ( $s['rider_pwb_pct'] ?? 2 ) ),
		'riderMap'   => (object) a4u_lic_rider_map( $s['rider_csv'] ?? '' ),
		'whatsapp'   => (string) $s['whatsapp'],
		'links'      => $links,
		'plans'      => $plans,
		'initPlan'   => $init,
		'title'      => $title,
		// v2.0: presentation + PDF
		'advisor'    => is_user_logged_in() && current_user_can( 'edit_posts' ),
		'vendor'     => plugin_dir_url( A4U_LIC_FILE ) . 'assets/vendor/',
		'brand'      => array(
			'name'   => (string) ( $s['brand_name'] ?? '' ),
			'agent'  => (string) ( $s['agent_name'] ?? '' ),
			'type'   => (string) ( $s['agent_type'] ?? '' ),
			'code'   => (string) ( $s['agency_code'] ?? '' ),
			'branch' => (string) ( $s['agency_branch'] ?? '' ),
			'phone'  => (string) ( $s['brand_phone'] ?? '' ),
			'email'  => (string) ( $s['brand_email'] ?? '' ),
			'web'    => (string) ( $s['brand_web'] ?? '' ),
			'logo'   => '' !== (string) ( $s['logo_url'] ?? '' ) ? (string) $s['logo_url'] : plugin_dir_url( A4U_LIC_FILE ) . 'assets/brand-logo.png',
			'gold'   => (string) ( $s['color_gold'] ?? '#B8924A' ),
			'green'  => (string) ( $s['color_green'] ?? '#3F5A22' ),
		),
	);
	wp_enqueue_style( 'a4u-lic' );
	wp_enqueue_script( 'a4u-lic' );
	wp_add_inline_script( 'a4u-lic', 'window.A4U_LIC=' . wp_json_encode( $cfg ) . ';', 'before' );
	$html = '<div id="a4u-lic-app" class="a4u-lic"><noscript>Please enable JavaScript to use the LIC calculator.</noscript></div>';
	// S7: सगळ्या plan pages च्या links (Google ला सापडण्यासाठी)
	$slug = a4u_lic_base_slug();
	$html .= '<nav class="a4u-lic a4u-plan-links" aria-label="LIC plan calculators"><strong>Plan-wise calculators:</strong> ';
	$html .= implode( ' · ', array_map( function ( $p ) use ( $slug ) {
		return '<a href="' . esc_url( home_url( '/' . $slug . '/' . $p['id'] . '/' ) ) . '">' . esc_html( $p['name'] ) . '</a>';
	}, $plans ) ) . '</nav>';
	static $faq_done = false;
	if ( ! empty( $s['faq'] ) && ! $faq_done ) { $html .= a4u_lic_faq_html(); $faq_done = true; }
	return $html;
} );

function a4u_lic_faq_items() {
	return array(
		array( 'Is this an official LIC premium calculator?', 'No. This is an educational illustration tool by Sahare Financial Services. It is not provided by LIC of India. Please check the final premium and benefits in the official LIC policy document or sales illustration before buying.' ),
		array( 'How accurate are the premiums shown?', 'Where exact LIC tariff rates are loaded, the premium is exact. Otherwise the calculator estimates the premium from the sample premiums printed in the official LIC sales brochure for that plan, so results for ages and terms between the printed samples may differ slightly from the actual premium.' ),
		array( 'Is GST charged on LIC premiums?', 'Premiums for individual life insurance policies are exempt from GST from 22 September 2025. You can still change the GST % in the options to see other scenarios.' ),
		array( 'What is the difference between guaranteed and non-guaranteed benefits?', 'Basic Sum Assured, survival or income benefits and Guaranteed Additions written in the policy are guaranteed. Bonuses such as Simple Reversionary Bonus and Final Additional Bonus are declared by LIC every year and are not guaranteed.' ),
		array( 'Why are plans 914, 915, 936 and 945 not available?', 'LIC withdrew these versions from 1 October 2024 and replaced them with modified plans 714, 715, 736 and 745, with revised premium rates and a higher minimum Sum Assured. Existing policies under the old plan numbers continue as per their original terms.' ),
		array( 'Can I calculate by my premium budget instead of Sum Assured?', 'Yes. Choose "By Premium budget", enter how much you can pay per installment, and the calculator finds the highest Sum Assured that fits your budget, rounded to the allowed multiple.' ),
		array( 'How is age calculated for LIC plans?', 'Most LIC plans use age nearer birthday. If your last birthday was more than six months ago, your age is counted as the next year. Enter your date of birth and the calculator works it out for you.' ),
		array( 'How can I compare two LIC plans?', 'Calculate one plan, then use the Compare section below the result. The second plan is calculated with the same age, Sum Assured and payment mode so the figures are easy to compare side by side.' ),
	);
}

function a4u_lic_faq_html() {
	$items  = a4u_lic_faq_items();
	$schema = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array() );
	$out    = '<section class="a4u-lic a4u-faq"><h2>LIC Calculator – FAQs</h2>';
	foreach ( $items as $it ) {
		$out .= '<details><summary>' . esc_html( $it[0] ) . '</summary><p>' . esc_html( $it[1] ) . '</p></details>';
		$schema['mainEntity'][] = array( '@type' => 'Question', 'name' => $it[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $it[1] ) );
	}
	$out .= '</section>';
	$out .= '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
	return $out;
}
